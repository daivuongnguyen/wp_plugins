<?php
namespace SlimSEOPro\LinkManager\Integrations;

class Bricks extends Base {
	protected $location = 'bricks';

	public function is_active(): bool {
		return defined( 'BRICKS_VERSION' );
	}

	protected function get_content( int $post_id ): string {
		// Set the post_id in 'Database' to avoid errors
		\Bricks\Database::$page_data['preview_or_post_id'] = $post_id;

		if ( ! \Bricks\Helpers::render_with_bricks( $post_id ) ) {
			return '';
		}

		$bricks_data = get_post_meta( $post_id, BRICKS_DB_PAGE_CONTENT, true );

		return $bricks_data ? (string) \Bricks\Frontend::render_data( $bricks_data ) : '';
	}

	public function ignore_update_link_url( bool $ignore, array $link, string $old_url, string $new_url ): bool {
		// Set the post_id in 'Database' to avoid errors
		\Bricks\Database::$page_data['preview_or_post_id'] = $link['source_id'];

		return \Bricks\Helpers::render_with_bricks( $link['source_id'] ) ?: $ignore;
	}
}
