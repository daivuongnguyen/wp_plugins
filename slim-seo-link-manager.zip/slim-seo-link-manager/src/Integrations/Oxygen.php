<?php
namespace SlimSEOPro\LinkManager\Integrations;

class Oxygen extends Base {
	protected $location = 'oxygen';

	protected function is_active(): bool {
		return defined( 'CT_VERSION' );
	}

	protected function get_content( int $post_id ): string {
		if ( 'ct_template' === get_post_type( $post_id ) ) {
			return '';
		}

		$post_template = intval( get_post_meta( $post_id, 'ct_other_template', true ) );

		if ( -1 === $post_template ) {
			return '';
		} elseif ( 0 === $post_template ) {
			$default_template = ct_get_posts_template( $post_id );

			if ( empty( $default_template->ID ) ) {
				return '';
			}

			$post_template = $default_template->ID;
		}

		$data = '';
		$json = get_post_meta( $post_template, 'ct_builder_json', true );

		if ( ! $json ) {
			$data = ct_do_shortcode( get_post_meta( $post_template, 'ct_builder_shortcodes', true ) );
		} else {
			global $oxygen_doing_oxygen_elements;

			// phpcs:ignore
			$oxygen_doing_oxygen_elements = true;

			$data = do_oxygen_elements( json_decode( $json, true ) );
		}

		return $data;
	}

	public function ignore_update_link_url( bool $ignore, array $link, string $old_url, string $new_url ): bool {
		return 'ct_template' === get_post_type( $link['source_id'] ) || $this->location === $link['location'] ? true : $ignore;
	}

	public function remove_post_types( array $post_types ): array {
		unset( $post_types['ct_template'] );
		unset( $post_types['oxy_user_library'] );
		return $post_types;
	}
}
