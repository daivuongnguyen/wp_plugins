<?php
namespace SlimSEOPro\LinkManager\Integrations;

class Elementor extends Base {
	protected $location = 'elementor';

	protected function is_active(): bool {
		return defined( 'ELEMENTOR_VERSION' );
	}

	protected function get_content( int $post_id ): string {
		$frontend = new \Elementor\Frontend;

		return $frontend->get_builder_content( $post_id ) ?: '';
	}

	public function update_link_url( array $link, string $old_url, string $new_url ) {
		if ( $this->location !== $link['location'] ) {
			return;
		}

		global $wpdb;

		// @codingStandardsIgnoreStart cannot use `$wpdb->prepare` because it remove's the backslashes
		$wpdb->query(
			"UPDATE {$wpdb->postmeta} " .
			"SET `meta_value` = REPLACE(`meta_value`, '" . str_replace( '/', '\\\/', $old_url ) . "', '" . str_replace( '/', '\\\/', $new_url ) . "') " .
			"WHERE `post_id` = " . $link['source_id'] . " AND `meta_key` = '_elementor_data' AND `meta_value` LIKE '[%' ;" ); // meta_value LIKE '[%' are json formatted
		// @codingStandardsIgnoreEnd
	}

	public function remove_post_types( array $post_types ): array {
		unset( $post_types['elementor_library'] );
		unset( $post_types['e-landing-page'] );

		return $post_types;
	}
}
