<?php
namespace SlimSEOPro\LinkManager\Integrations;

use SlimSEOPro\LinkManager\BackgroundProcessing\CheckLinkStatus;
use SlimSEOPro\LinkManager\Database\Links as DbLinks;
use SlimSEOPro\LinkManager\Helper;

abstract class Base {
	protected $location;

	public function __construct() {
		add_action( 'after_setup_theme', [ $this, 'setup' ] );
	}

	abstract protected function is_active(): bool;

	public function setup() {
		if ( ! $this->is_active() ) {
			return;
		}

		add_action( 'save_post', [ $this, 'save' ], 30 );
		add_action( 'slim_seo_link_manager_update_link_url', [ $this, 'update_link_url' ], 20, 3 );
		add_filter( 'slim_seo_link_manager_get_all_links_from_post', [ $this, 'get_all_links_from_post' ], 20, 2 );
		add_filter( 'slim_seo_link_manager_ignore_update_link_url', [ $this, 'ignore_update_link_url' ], 20, 4 );
		add_filter( 'slim_seo_link_manager_post_types', [ $this, 'remove_post_types' ] );

		// Filter content to suggest links & keywords.
		add_filter( 'slim_seo_link_manager_content', [ $this, 'filter_content' ], 10, 2 );
	}

	/**
	 * Filter content to suggest links & keywords.
	 */
	public function filter_content( string $content, int $post_id ): string {
		return $this->get_content( $post_id ) ?: $content;
	}

	/**
	 * Get content from page builders.
	 */
	abstract protected function get_content( int $post_id ): string;

	protected function get_links( int $source_id ): array {
		$links   = [];
		$content = $this->get_content( $source_id );

		if ( ! $content ) {
			return $links;
		}

		$source_type = get_post_type( $source_id );
		$links       = Helper::get_links_from_text( $content, $source_id, $source_type, $this->location );

		if ( ! empty( $links ) ) {
			$links = array_map( function ( $link ) {
				$link = array_merge( $link, Helper::get_info_from_url( $link['url'] ) );

				return $link;
			}, $links );
		}

		return $links;
	}

	public function save( int $post_id ) {
		$source_id = wp_is_post_revision( $post_id ) ?: $post_id;
		$links     = $this->get_links( $source_id );

		if ( empty( $links ) ) {
			return;
		}

		$source_type = get_post_type( $source_id );

		$tbl_links = new DbLinks();
		$tbl_links->delete_all( $source_id, $source_type );
		$tbl_links->add( $links );

		// Check link status in background
		$links = $tbl_links->get_links_by_object( $source_id, $source_type );

		$check_link_status = new CheckLinkStatus();

		foreach ( $links as $link ) {
			$check_link_status->push_to_queue( $link );
		}

		$check_link_status->save()->dispatch();
	}

	public function update_link_url( array $link, string $old_url, string $new_url ) {}

	public function get_all_links_from_post( array $links, int $post_id ): array {
		$builder_links = $this->get_links( $post_id );

		if ( empty( $builder_links ) ) {
			return $links;
		}

		$links = array_filter( $links, function ( $link ) {
			return $link['location'] !== 'post_content';
		} );

		$links = array_merge( $links, $builder_links );

		return $links;
	}

	public function ignore_update_link_url( bool $ignore, array $link, string $old_url, string $new_url ): bool { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter
		return $ignore;
	}

	public function remove_post_types( array $post_types ): array {
		return $post_types;
	}
}
