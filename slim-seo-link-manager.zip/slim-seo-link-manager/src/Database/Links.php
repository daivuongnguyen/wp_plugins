<?php
// phpcs:ignoreFile
namespace SlimSEOPro\LinkManager\Database;

use SlimSEOPro\LinkManager\Helper;

class Links {
	public function __construct() {
		global $wpdb;

		$wpdb->tables[]       = 'slim_seo_links';
		$wpdb->slim_seo_links = $wpdb->prefix . 'slim_seo_links';
	}

	public function get_total(): int {
		global $wpdb;
		return $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->slim_seo_links}" );
	}

	public function get_all(): array {
		global $wpdb;
		return $wpdb->get_results( "SELECT * FROM {$wpdb->slim_seo_links}", ARRAY_A );
	}

	public function get( int $link_id ): array {
		global $wpdb;

		$result = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT *
				FROM {$wpdb->slim_seo_links}
				WHERE `id` = %d",
				$link_id
			),
			ARRAY_A
		);

		return ! empty( $result ) ? $result : [];
	}

	public function get_total_links_by_object( int $object_id, string $object_type, string $type = 'source' ): int {
		global $wpdb;

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT count(*)
				FROM {$wpdb->slim_seo_links}
				WHERE " . ( 'source' === $type ? "`source_id` = %d AND `source_type` = '%s'" : "`target_id` = %d AND `target_type` = '%s'" ),
				$object_id,
				$object_type
			)
		);
	}

	public function get_links_by_object( int $object_id, string $object_type, string $type = 'source', int $limit = 0, int $offset = 0 ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM {$wpdb->slim_seo_links}
				WHERE " . ( 'source' === $type ? "`source_id` = %d AND `source_type` = '%s'" : "`target_id` = %d AND `target_type` = '%s'" )
				. ( $limit ? " LIMIT {$limit} OFFSET {$offset}" : '' ),
				$object_id,
				$object_type
			),
			ARRAY_A
		);
	}

	public function get_total_top( string $get, string $search_keyword = '' ): int {
		global $wpdb;

		$group_by  = '';
		$condition = '';

		switch ( $get ) {
			case 'linked_pages':
				$group_by  = '`target_id`, `target_type`';
				$condition = "WHERE `target_id` <> '0'";

				break;

			case 'external_links':
				$group_by  = '`url`';
				$condition = "WHERE `type` = 'external'";

				break;

			case 'keywords':
				$group_by = '`anchor_text`';

				break;

			case 'links_status':
				$group_by = '`status`';

				break;

			case 'orphan_pages':
				return count( $this->get_orphan_pages( 0, 0, $search_keyword ) );
		}

		if ( $search_keyword ) {
			$search_condition = Helper::get_sql_condition_by_keyword( $get, $search_keyword );

			if ( $search_condition ) {
				$condition .= $search_condition;
			}
		}

		return $wpdb->get_var(
			"SELECT COUNT(*)
			FROM (
				SELECT COUNT(*)
				FROM {$wpdb->slim_seo_links}
				{$condition}
				GROUP BY {$group_by}
			) AS TopLinks"
		);
	}

	public function get_top( string $get, int $limit = 0, int $offset = 0, $search_keyword = '' ): array {
		global $wpdb;

		$fields_to_get   = '';
		$group_by        = '';
		$condition       = '';
		$order_by        = '`amount`';
		$order           = 'DESC';
		$second_order_by = '';

		switch ( $get ) {
			case 'linked_pages':
				$fields_to_get   = '`url`, `target_id`, `target_type`';
				$group_by        = '`target_id`, `target_type`';
				$condition       = "WHERE `target_id` <> '0'";
				$second_order_by = ', `target_id` ASC';

				break;

			case 'external_links':
				$fields_to_get   = '`url`';
				$group_by        = '`url`';
				$condition       = "WHERE `type` = 'external'";
				$second_order_by = ', `url` ASC';

				break;

			case 'keywords':
				$fields_to_get   = '`anchor_text`';
				$group_by        = '`anchor_text`';
				$second_order_by = ', `anchor_text` ASC';

				break;

			case 'links_status':
				$fields_to_get = '`status`';
				$group_by      = '`status`';
				$order_by      = '`status`';
				$order         = 'ASC';

				break;

			case 'orphan_pages':
				return $this->get_orphan_pages( $limit, $offset, $search_keyword );
		}

		if ( $search_keyword ) {
			$condition .= Helper::get_sql_condition_by_keyword( $get, $search_keyword );
		}

		$sql_query = "
			SELECT COUNT(*) as amount, {$fields_to_get}
			FROM {$wpdb->slim_seo_links}
			{$condition}
			GROUP BY {$group_by}
			ORDER BY {$order_by} {$order} {$second_order_by}
		";

		if ( $limit ) {
			$sql_query .= " LIMIT {$limit} OFFSET {$offset}";
		}

		return $wpdb->get_results( $sql_query, ARRAY_A );
	}

	public function get_total_links_by_column_value( string $column_name, string $value ): int {
		global $wpdb;

		return $wpdb->get_var(
			$wpdb->prepare(
				"SELECT count(*)
				FROM {$wpdb->slim_seo_links}
				WHERE {$column_name} = '%s'",
				$value
			)
		);
	}

	public function get_links_by_column_value( string $column_name, string $value, int $limit = 0, int $offset = 0 ): array {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM {$wpdb->slim_seo_links}
				WHERE {$column_name} = '%s'"
				. ( $limit ? " LIMIT {$limit} OFFSET {$offset}" : '' ),
				$value
			),
			ARRAY_A
		);
	}

	public function search_links_by_url( string $url, int $limit = 0, array $exclude = [] ): array {
		global $wpdb;

		return $wpdb->get_results(
			"SELECT *
			FROM {$wpdb->slim_seo_links}
			WHERE `url` like '%{$url}%'"
			. ( ! empty( $exclude ) ? ' AND `id` NOT IN (' . implode( ', ', $exclude ) . ')' : '' )
			. ( $limit ? " LIMIT {$limit}" : '' ),
			ARRAY_A
		);
	}

	public function get_orphan_pages( int $limit = 0, int $offset = 0, $search_keyword = '' ): array {
		global $wpdb;

		$post_types = implode( ', ', array_map( function( $post_type ) {
			return "'" . $post_type . "'";
		}, Helper::get_post_types() ) );

		return $wpdb->get_results(
			"SELECT `ID` as 'target_id', `post_type` as 'target_type'
			FROM {$wpdb->posts}
			WHERE `post_status` = 'publish'
				AND `post_type` IN ({$post_types})
				AND `post_title` LIKE '%{$search_keyword}%'
				AND `ID` NOT IN (
					SELECT DISTINCT `target_id`
					FROM {$wpdb->slim_seo_links}
					WHERE `target_type` IN ({$post_types})
				)
			"
			. ( $limit ? " LIMIT {$limit} OFFSET {$offset}" : '' ),
			ARRAY_A
		);
	}

	public function add( array $links ) {
		global $wpdb;

		foreach ( $links as $link ) {
			unset( $link['id'] );

			$wpdb->insert(
				$wpdb->slim_seo_links,
				$link
			);
		}
	}

	public function update( array $link ) {
		global $wpdb;

		$wpdb->update(
			$wpdb->slim_seo_links,
			$link,
			[ 'id' => $link['id'] ]
		);
	}

	public function delete_all( int $object_id, string $object_type, string $type = 'source' ) {
		global $wpdb;

		$wpdb->delete(
			$wpdb->slim_seo_links,
			'source' === $type ? [
				'source_id'   => $object_id,
				'source_type' => $object_type,
			] : [
				'target_id'   => $object_id,
				'target_type' => $object_type,
			]
		);
	}

	public function truncate() {
		global $wpdb;

		$wpdb->query( "TRUNCATE TABLE $wpdb->slim_seo_links" );
	}
}
