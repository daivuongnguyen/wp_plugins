<?php
namespace SlimSEOPro\LinkManager\LinkSuggestions;

use Exception;
use voku\helper\StopWords;
use SlimSEOPro\LinkManager\Database\Links;
use SlimSEOPro\LinkManager\Helper;

class Controller {
	private $stop_words        = [];
	const KEYWORD_MIN_COUNT    = 5;
	const MIN_COMMON_WORDS     = 2;
	const MIN_MATCH_PERCENTAGE = 0.2;

	public function suggest_links( int $post_id, bool $same_taxonomies ): array {
		$content = $this->get_content( $post_id );
		return $this->suggest_links_from_text( $content, $post_id, $same_taxonomies );
	}

	public function suggest_keywords( int $post_id ): array {
		$content = $this->get_content( $post_id );

		// To suggest keywords, we don't need HTML.
		$content = wp_strip_all_tags( strip_shortcodes( $content ) );

		// Divide text to sentences. Don't use $this->get_sentence() as it's used for HTML content.
		$sentences = preg_split( '/((?<=[.?!])\s+|\n)/s', $content, -1, PREG_SPLIT_NO_EMPTY );
		$sentences = array_values( array_filter( array_map( 'trim', $sentences ) ) );

		// Add post title as well.
		$sentences[] = get_post_field( 'post_title', $post_id );

		$words_list = array_reduce( $sentences, function ( $result, $sentence ) {
			$words               = explode( ' ', $sentence );
			$words               = array_values( array_filter( array_map( 'trim', $words ) ) );
			$sentence_word_count = count( $words );
			$words_list          = [];

			for ( $i = 0; $i < $sentence_word_count; $i++ ) {
				// 1-word keyword.
				$words_list[] = [ $words[ $i ] ];

				// 2-words keyword.
				if ( $i < $sentence_word_count - 1 ) {
					$words_list[] = [
						$words[ $i ],
						$words[ $i + 1 ],
					];
				}

				// 3-words keyword.
				if ( $i < $sentence_word_count - 2 ) {
					$words_list[] = [
						$words[ $i ],
						$words[ $i + 1 ],
						$words[ $i + 2 ],
					];
				}
			}

			foreach ( $words_list as $key => $value ) {
				$initial_length = count( $value );
				$value          = $this->normalize_words( $value );

				if ( $initial_length > count( $value ) ) {
					unset( $words_list[ $key ] );
				} else {
					$words_list[ $key ] = implode( ' ', $value );
				}
			}

			return array_merge( $result, $words_list );
		}, [] );

		// Get keywords that occurs more than the KEYWORD_MIN_COUNT.
		$words_list = array_count_values( $words_list );
		$words_list = array_filter( $words_list, function ( $value ) {
			return $value >= self::KEYWORD_MIN_COUNT;
		} );
		arsort( $words_list );

		return array_keys( $words_list );
	}

	public function build_query_args( int $object_id = 0, bool $same_taxonomies = false ): array {
		if ( ! $object_id ) {
			return [];
		}

		$args = [];

		// Ignore the current post
		$ignored_posts = [ $object_id ];

		// Add posts that are already linked in the current post to list of ignored posts
		$linked_posts = $this->get_linked_posts( $object_id );

		if ( ! empty( $linked_posts ) ) {
			$ignored_posts = array_merge( $ignored_posts, $linked_posts );
		}

		$args['post__not_in'] = $ignored_posts;

		if ( ! $same_taxonomies ) {
			return $args;
		}

		// Same taxonomies.
		$terms = $this->get_post_terms( $object_id );

		if ( empty( $terms ) ) {
			return $args;
		}

		$tax_query = [ 'relation' => 'OR' ];

		foreach ( $terms as $taxonomy => $term_ids ) {
			$tax_query[] = [
				'taxonomy' => $taxonomy,
				'terms'    => $term_ids,
			];
		}

		// phpcs:ignore WordPress.DB.SlowDBQuery
		$args['tax_query'] = $tax_query;

		return $args;
	}

	private function get_content( int $post_id ): string {
		$content = get_post_field( 'post_content', $post_id );
		$content = do_shortcode( $content );
		$content = do_blocks( $content );
		$content = (string) apply_filters( 'slim_seo_link_manager_content', $content, $post_id );

		// Remove script
		if ( false !== strpos( $content, '<script' ) ) {
			$content = mb_ereg_replace( '<script(?:[^>]*)>(.*?)<\/script>', '', $content );
		}

		// Remove style
		if ( false !== strpos( $content, '<style' ) ) {
			$content = mb_ereg_replace( '<style(?:[^>]*)>(.*?)<\/style>', '', $content );
		}

		return $content;
	}

	private function get_linked_posts( int $post_id ): array {
		$tbl_links      = new Links;
		$outbound_links = $tbl_links->get_links_by_object( $post_id, get_post_type( $post_id ) );

		// Get links to posts only.
		$outbound_links = array_filter( $outbound_links, function ( $outbound_link ) {
			return ! empty( $outbound_link['target_id'] ) && ! str_contains( $outbound_link['target_type'], 'tax:' );
		} );

		return wp_list_pluck( $outbound_links, 'target_id' );
	}

	private function get_post_terms( int $post_id ): array {
		$post_terms = [];
		$taxonomies = get_post_taxonomies( $post_id );

		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_the_terms( $post_id, $taxonomy );

			if ( empty( $terms ) || is_wp_error( $terms ) ) {
				continue;
			}

			foreach ( $terms as $term ) {
				if ( empty( $post_terms[ $taxonomy ] ) ) {
					$post_terms[ $taxonomy ] = [];
				}
				$post_terms[ $taxonomy ][] = $term->term_id;
			}
		}

		return $post_terms;
	}

	private function get_sentences( string $text ): array {
		// Strip all HTML excepts <a>.
		$text = trim( wp_kses( $text, [
			'a' => [
				'href' => [],
			],
		] ) );

		// Divide text to sentences
		$sentences = preg_split( '/((?<=[.?!])\s+|\n)/', $text, -1, PREG_SPLIT_NO_EMPTY );
		$sentences = array_values( array_filter( array_map( 'trim', $sentences ) ) );

		foreach ( $sentences as $index => $sentence ) {
			// Remove sentence if it already has link.
			if ( preg_match( '/<a [^>]*?>/is', $sentence ) ) {
				unset( $sentences[ $index ] );
				continue;
			}

			$sentences[ $index ] = trim( wp_strip_all_tags( strip_shortcodes( $sentence ) ) );
		}

		return array_values( array_filter( $sentences ) );
	}

	private function sentence_to_words( string $sentence ): array {
		$words = explode( ' ', $sentence );
		$words = array_values( array_filter( array_map( 'trim', $words ) ) );
		$words = $this->normalize_words( $words );
		$words = array_unique( $words );

		return $words;
	}

	private function suggest_links_from_text( string $text, int $object_id = 0, bool $same_taxonomies = false, string $location = 'post_content' ): array {
		$args      = $this->build_query_args( $object_id, $same_taxonomies );
		$args      = apply_filters( 'slim_seo_link_manager_link_suggestions_args', $args );
		$all_posts = Helper::get_posts( $args );

		$suggestions = [];
		$sentences   = $this->get_sentences( $text );
		$posts       = array_map( function ( $post ) {
			return [
				'id'    => $post->ID,
				'title' => $post->post_title,
				'url'   => get_permalink( $post->ID ),
				'words' => array_map( 'strtolower', $this->sentence_to_words( $post->post_title ) ),
			];
		}, $all_posts );

		foreach ( $sentences as $sentence ) {
			if ( empty( $sentence ) ) {
				continue;
			}

			$suggestions_for_sentence = [];
			$words                    = array_map( 'strtolower', $this->sentence_to_words( $sentence ) );
			$words_count              = count( $words );

			if ( ! $words_count ) {
				continue;
			}

			foreach ( $posts as $post ) {
				$intersect_words       = array_intersect( $post['words'], $words );
				$intersect_words_count = count( $intersect_words );
				$matched_percentage    = floatval( $intersect_words_count / $words_count );

				if ( $matched_percentage >= self::MIN_MATCH_PERCENTAGE && $intersect_words_count >= self::MIN_COMMON_WORDS ) {
					$suggestions_for_sentence[] = [
						'post'               => $post,
						'intersect_words'    => $intersect_words,
						'matched_percentage' => $matched_percentage,
					];
				}
			}

			if ( empty( $suggestions_for_sentence ) ) {
				continue;
			}

			// Sort by matched percentage.
			if ( count( $suggestions_for_sentence ) > 1 ) {
				usort( $suggestions_for_sentence, function ( $l1, $l2 ) {
					return $l1['matched_percentage'] < $l2['matched_percentage'];
				} );
			}

			foreach ( $suggestions_for_sentence as $suggestion ) {
				$suggestions[] = array_merge( [
					'sentence' => $sentence,
					'location' => $location,
				], $suggestion );
			}
		}

		return $suggestions;
	}

	private function normalize_words( array $words ): array {
		// Remove special characters, numbers and convert word to lower case
		$words = array_map( function ( $word ) {
			return strtolower( preg_replace( '/[0-9.~()<>?;:`!@#$%^&*()\[\]{}_+=|\\-]/', '', $word ) );
		}, $words );

		// Remove stop words
		$this->get_stop_words();
		$words = array_filter( $words, function ( $word ) {
			return $word && ! in_array( $word, $this->stop_words, true );
		} );

		return $words;
	}

	private function get_stop_words(): void {
		if ( ! empty( $this->stop_words ) ) {
			return;
		}

		try {
			$locale           = get_locale();
			$stop_words       = new StopWords();
			$this->stop_words = $stop_words->getStopWordsFromLanguage( ! empty( $locale ) ? substr( $locale, 0, 2 ) : 'en' );
		} catch ( Exception $e ) {
			return;
		}
	}
}
