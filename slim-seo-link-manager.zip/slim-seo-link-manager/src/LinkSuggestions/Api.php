<?php
namespace SlimSEOPro\LinkManager\LinkSuggestions;

use SlimSEOPro\LinkManager\Api\Base;
use SlimSEOPro\LinkManager\Helper;
use WP_REST_Server;
use WP_REST_Request;

class Api extends Base {
	private $controller;

	public function set_controller( Controller $controller ) {
		$this->controller = $controller;
	}

	public function register_routes() {
		register_rest_route( 'slim-seo-link-manager', 'link_suggestions', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'suggest_links' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'keyword_suggestions', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'suggest_keywords' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'search', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'search' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );
	}

	public function suggest_links( WP_REST_Request $request ): array {
		$object_id        = (int) $request->get_param( 'object_id' );
		$same_taxonomies  = (bool) $request->get_param( 'same_taxonomies' );
		$link_suggestions = $this->controller->suggest_links( $object_id, $same_taxonomies );

		return $link_suggestions;
	}

	public function suggest_keywords( WP_REST_Request $request ): array {
		$object_id = (int) $request->get_param( 'object_id' );

		return $this->controller->suggest_keywords( $object_id );
	}

	public function search( WP_REST_Request $request ): array {
		$object_id       = (int) $request->get_param( 'object_id' );
		$same_taxonomies = (bool) $request->get_param( 'same_taxonomies' );

		$args      = $this->controller->build_query_args( $object_id, $same_taxonomies );
		$args['s'] = $request->get_param( 'keyword' );
		$args      = apply_filters( 'slim_seo_link_manager_search_args', $args );

		$posts = Helper::get_posts( $args );
		$pages = [];
		if ( empty( $posts ) ) {
			return $pages;
		}

		foreach ( $posts as $post ) {
			$pages[] = [
				'id'    => $post->ID,
				'title' => $post->post_title,
				'link'  => get_permalink( $post->ID ),
			];
		}

		return $pages;
	}
}
