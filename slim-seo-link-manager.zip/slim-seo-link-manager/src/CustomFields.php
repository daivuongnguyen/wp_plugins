<?php
namespace SlimSEOPro\LinkManager;

class CustomFields {
	public function __construct() {
		add_filter( 'slim_seo_link_manager_get_all_links_from_post', [ $this, 'get_all_links_from_post' ], 30, 2 );
		add_filter( 'slim_seo_link_manager_outbound_links', [ $this, 'outbound_links' ], 30, 2 );
	}

	public function get_all_links_from_post( array $links, int $post_id ): array {
		$custom_fields_links = $this->get_post_custom_fields_links( $post_id );

		if ( empty( $custom_fields_links ) ) {
			return $links;
		}

		$links = array_merge( $links, $custom_fields_links );

		return $links;
	}

	public function outbound_links( $links, int $post_id ) {
		$custom_fields_links = $this->get_post_custom_fields_links( $post_id );

		if ( empty( $custom_fields_links ) ) {
			return $links;
		}

		// Remove all links that are not from post content
		$links = array_filter( $links, function ( $link ) {
			return $link['location'] === 'post_content';
		} );
		$links = array_merge( $links, $custom_fields_links );

		return $links;
	}

	public function get_post_custom_fields_links( int $post_id ): array {
		$custom_fields = apply_filters( 'slim_seo_link_manager_post_custom_fields', [] );
		$links         = [];

		if ( empty( $custom_fields ) ) {
			return $links;
		}

		$post_type = get_post_type( $post_id );

		foreach ( $custom_fields as $custom_field ) {
			$custom_field_data = get_post_meta( $post_id, $custom_field, true );

			if ( empty( $custom_field_data ) ) {
				continue;
			}

			$custom_field_links = Helper::get_links_from_text( $custom_field_data, $post_id, $post_type, "custom_field: {$custom_field}" );

			if ( empty( $custom_field_links ) ) {
				continue;
			}

			$custom_field_links = array_map( function ( $link ) {
				$link = array_merge( $link, Helper::get_info_from_url( $link['url'] ) );

				return $link;
			}, $custom_field_links );

			$links = array_merge( $links, $custom_field_links );
		}

		return $links;
	}
}
