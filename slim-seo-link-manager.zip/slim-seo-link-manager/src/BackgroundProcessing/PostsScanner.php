<?php
namespace SlimSEOPro\LinkManager\BackgroundProcessing;

use Exception;
use SlimSEOPro\LinkManager\Helper;
use SlimSEOPro\LinkManager\Database\Links as DbLinks;

class PostsScanner extends \WP_Background_Process {
	protected $action = 'posts_scanner';

	public function __construct() {
		parent::__construct();

		add_filter( "{$this->identifier}_post_args", [ 'SlimSEOPro\LinkManager\Helper', 'background_processing_dispatch_post_args' ] );
	}

	protected function task( $post_id ): bool {
		$keep_item_in_queue  = false;
		$total_scanned_posts = Helper::get_total_scanned( 'posts' );

		Helper::update_total_scanned( 'posts', $total_scanned_posts + 1 );

		try {
			$post_type = get_post_type( $post_id );
			$tbl_links = new DbLinks();
			$links     = Helper::get_links_from_text( get_post_field( 'post_content', $post_id ), $post_id, $post_type, 'post_content' );
			$links     = apply_filters( 'slim_seo_link_manager_get_all_links_from_post', $links, $post_id );

			if ( empty( $links ) ) {
				return $keep_item_in_queue;
			}

			foreach ( $links as $link_index => $link ) {
				$link = Helper::get_link_detail( $link, 'target' );

				unset( $link['target_name'] );

				$links[ $link_index ] = $link;
			}

			$tbl_links->add( $links );

			return $keep_item_in_queue;
		} catch ( Exception $e ) {
			return $keep_item_in_queue;
		}
	}

	protected function complete() {
		parent::complete();

		$links_scanner = new LinksScanner();
		$tbl_links     = new DbLinks();
		$links         = $tbl_links->get_all();

		if ( empty( $links ) ) {
			Helper::set_scanner_running( false );
			return;
		}

		update_option( SLIM_SEO_LINK_MANAGER_TOTAL_LINKS, count( $links ) );

		foreach ( $links as $link ) {
			$links_scanner->push_to_queue( $link['id'] );
		}

		$links_scanner->save()->dispatch();
	}
}
