<?php
namespace SlimSEOPro\LinkManager\BackgroundProcessing;

use Exception;
use SlimSEOPro\LinkManager\Helper;
use SlimSEOPro\LinkManager\Database\Links as DbLinks;

class LinksScanner extends \WP_Background_Process {
	protected $action = 'links_scanner';

	public function __construct() {
		parent::__construct();

		add_filter( "{$this->identifier}_post_args", [ 'SlimSEOPro\LinkManager\Helper', 'background_processing_dispatch_post_args' ] );
	}

	protected function task( $link_id ): bool {
		$keep_item_in_queue  = false;
		$total_scanned_links = Helper::get_total_scanned( 'links' );

		Helper::update_total_scanned( 'links', $total_scanned_links + 1 );

		try {
			$tbl_links = new DbLinks();
			$link      = $tbl_links->get( $link_id );

			if ( empty( $link ) ) {
				return $keep_item_in_queue;
			}

			$link['status'] = Helper::get_link_status_code( $link );

			$tbl_links->update( $link );

			return $keep_item_in_queue;
		} catch ( Exception $e ) {
			return $keep_item_in_queue;
		}
	}

	protected function complete() {
		parent::complete();

		Helper::set_scanner_running( false );
	}
}
