<?php
namespace SlimSEOPro\LinkManager\BackgroundProcessing;

use SlimSEOPro\LinkManager\Helper;
use SlimSEOPro\LinkManager\Database\Links as DbLinks;

class CheckLinkStatus extends \WP_Background_Process {
	protected $action = 'check_link_status';

	public function __construct() {
		parent::__construct();

		add_filter( "{$this->identifier}_post_args", [ 'SlimSEOPro\LinkManager\Helper', 'background_processing_dispatch_post_args' ] );
	}

	protected function task( $link ): bool {
		$keep_item_in_queue = false;

		$link['status'] = Helper::get_link_status_code( $link );

		$tbl_links = new DbLinks();
		$tbl_links->update( $link );

		return $keep_item_in_queue;
	}
}
