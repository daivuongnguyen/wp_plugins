<?php
namespace SlimSEOPro\LinkManager\BackgroundProcessing;

use SlimSEOPro\LinkManager\Helper;

class LinkUpdater extends \WP_Background_Process {
	protected $action = 'link_updater';

	public function __construct() {
		parent::__construct();

		add_filter( "{$this->identifier}_post_args", [ 'SlimSEOPro\LinkManager\Helper', 'background_processing_dispatch_post_args' ] );
	}

	protected function task( $link ): bool {
		$keep_item_in_queue = false;
		$old_permalink      = $link['old_permalink'];
		$new_permalink      = $link['new_permalink'];

		unset( $link['old_permalink'] );
		unset( $link['new_permalink'] );

		$link = Helper::update_link_url( $link, $old_permalink, $new_permalink );

		return $keep_item_in_queue;
	}
}
