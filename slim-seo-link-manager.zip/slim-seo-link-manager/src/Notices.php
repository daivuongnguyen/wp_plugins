<?php
namespace SlimSEOPro\LinkManager;

class Notices {
	public function __construct() {
		add_action( 'admin_notices', [ $this, 'links_scanner' ] );
	}

	public function links_scanner() {
		if ( ! Helper::is_scanner_running() ) {
			return;
		}

		$total_scanned_posts = Helper::get_total_scanned( 'posts' );
		$total_posts         = get_option( SLIM_SEO_LINK_MANAGER_TOTAL_POSTS );
		$total_scanned_links = Helper::get_total_scanned( 'links' );
		$total_links         = get_option( SLIM_SEO_LINK_MANAGER_TOTAL_LINKS );

		if ( $total_scanned_posts > $total_posts || $total_scanned_links > $total_links ) {
			Helper::set_scanner_running( false );

			return;
		}

		$message = sprintf(
			// Translators: %1$d - scanned links, %2$d - total links.
			'<li>' . __( 'Scanned links in %1$d/%2$d posts', 'slim-seo-link-manager' ) . '</li>',
			$total_scanned_posts,
			$total_posts
		);

		if ( $total_scanned_links ) {
			$message .= sprintf(
				// Translators: %1$d - scanned links, %2$d - total links.
				'<li>' . __( 'Checked HTTP status of %1$d/%2$d links.', 'slim-seo-link-manager' ) . '</li>',
				$total_scanned_links,
				$total_links
			);
		}

		printf(
			'<div class="notice notice-success is-dismissible">
				<p>%s</p>
				<ul>%s</ul>
			</div>',
			esc_html__( 'Links scanner is still processing...', 'slim-seo-link-manager' ),
			wp_kses_post( $message )
		);
	}
}
