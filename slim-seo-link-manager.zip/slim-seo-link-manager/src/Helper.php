<?php
namespace SlimSEOPro\LinkManager;

class Helper {
	public static function get_post_types(): array {
		$post_types = get_post_types( [ 'public' => true ] );

		unset( $post_types['attachment'] );

		$post_types = apply_filters( 'slim_seo_link_manager_post_types', $post_types );

		return array_keys( $post_types );
	}

	public static function get_taxonomies(): array {
		$taxonomies = get_taxonomies( [ 'public' => true ] );

		return $taxonomies;
	}

	public static function get_info_from_url( string $url ): array {
		$info = [
			'target_id'   => 0,
			'target_type' => '',
		];

		// Check if url is a post
		$post_id = url_to_postid( $url );

		if ( $post_id ) {
			return array_merge( $info, [
				'target_id'   => $post_id,
				'target_type' => get_post_type( $post_id ),
			] );
		}

		// Check if url is a term
		$taxonomies = self::get_taxonomies();

		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_terms( [
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			] );

			foreach ( $terms as $term ) {
				$term_link = get_term_link( $term );

				if ( $term_link && $url === $term_link ) {
					return array_merge( $info, [
						'target_id'   => $term->term_id,
						'target_type' => "tax: {$taxonomy}",
					] );
				}
			}
		}

		return $info;
	}

	public static function get_link_detail( array $link, string $get = 'source' ): array {
		if ( ( 'source' === $get || 'all' === $get )
			&& ! empty( $link['source_id'] )
			&& ! empty( $link['source_type'] )
		) {
			if ( false !== stripos( $link['source_type'], 'tax:' ) ) {
				$term = get_term( $link['source_id'] );

				if ( ! empty( $term->name ) ) {
					$link = array_merge( $link, [
						'source_name' => html_entity_decode( $term->name ),
						'source_url'  => get_term_link( $term ),
					] );
				}
			} else {
				$link = array_merge( $link, [
					'source_name' => html_entity_decode( get_the_title( $link['source_id'] ) ),
					'source_url'  => get_permalink( $link['source_id'] ),
				] );
			}
		}

		if ( ( 'target' === $get || 'all' === $get )
			&& 'external' !== ( $link['type'] ?? '' )
		) {
			if ( empty( $link['target_id'] ) ) {
				$link = array_merge( $link, self::get_info_from_url( self::get_full_url( $link['url'], $link ) ) );
			}

			if ( ! empty( $link['target_id'] ) && ! empty( $link['target_type'] ) ) {
				if ( false !== stripos( $link['target_type'], 'tax:' ) ) {
					$term = get_term( $link['target_id'] );

					if ( ! empty( $term->name ) ) {
						$link = array_merge( $link, [
							'target_name' => html_entity_decode( $term->name ),
						] );
					}
				} else {
					$link = array_merge( $link, [
						'target_name' => html_entity_decode( get_the_title( $link['target_id'] ) ),
					] );
				}
			}
		}

		return $link;
	}

	public static function get_links_from_text( string $text, int $source_id, string $source_type, string $location = 'post_content' ): array {
		$links = [];

		if ( empty( $text ) ) {
			return $links;
		}

		// Consider using single quote (') and double quote (") around attributes.
		// Use "s" modifier to match multiline.
		preg_match_all( '/<a.*?href=([\'"])([^>]*?)\1[^>]*?>(.*?)<\/a>/is', $text, $matches, PREG_SET_ORDER );

		if ( empty( $matches ) ) {
			return $links;
		}

		$home_url   = untrailingslashit( home_url() );
		$source_url = (string) get_permalink( $source_id );

		foreach ( $matches as $match ) {
			$url = $match[2];

			if (
				'_wp_link_placeholder' === $url
				|| 0 === strpos( $url, '#' )
				|| ( $source_url && 0 === stripos( $url, $source_url ) )
				|| ! apply_filters( 'slim_seo_link_manager_process_url', true, $url )
			) {
				continue;
			}

			$full_link = $match[0];
			$link      = [
				'source_id'   => $source_id,
				'source_type' => $source_type,
				'target_id'   => 0,
				'target_type' => '',
				'url'         => $url,
				'type'        => 'internal',
				'anchor_text' => $match[3],
				'anchor_type' => 'text',
				'location'    => $location,
				'nofollow'    => 0,
				'status'      => SLIM_SEO_LINK_MANAGER_DEFAULT_STATUS_CODE,
			];

			// Check if anchor is an image then anchor text is image's alt
			// Consider using single quote (') and double quote (") around attributes.
			// Use "s" modifier to match multiline.
			$image_pattern = '/<img.*?alt=([\'"])([^>]*?)\1[^>]*?>/is';

			if ( preg_match( $image_pattern, $link['anchor_text'] ) ) {
				$link['anchor_type'] = 'image';
				$link['anchor_text'] = preg_replace( $image_pattern, '$2', $link['anchor_text'] );
			}

			// Strip all tags of anchor text
			$link['anchor_text'] = wp_strip_all_tags( $link['anchor_text'] );

			// Check if url does not contain home URL then it's external link
			if ( false === stripos( self::get_full_url( $link['url'], $link ), $home_url ) ) {
				$link['type'] = 'external';
			}

			// Check rel
			// Consider using single quote (') and double quote (") around attributes.
			// Use "s" modifier to match multiline.
			$rel_pattern = '/<a.*?rel=([\'"])([^>]*?)\1[^>]*?>/is';

			if ( preg_match( $rel_pattern, $full_link ) ) {
				$rel = preg_replace( $rel_pattern, '$2', $full_link );

				if ( false !== stripos( $rel, 'nofollow' ) ) {
					$link['nofollow'] = 1;
				}
			}

			$links[] = $link;
		}

		return $links;
	}

	private static function get_http_code( string $url ): int {
		$links_cache = get_option( SLIM_SEO_LINK_MANAGER_LINKS_CACHE_NAME );
		$links_cache = ! empty( $links_cache ) ? $links_cache : [];
		$now         = strtotime( 'now' );

		if ( isset( $links_cache[ $url ] ) && $links_cache[ $url ]['updated_at'] + DAY_IN_SECONDS >= $now ) {
			return $links_cache[ $url ]['status'];
		}

		// phpcs:disable
		$http_code   = SLIM_SEO_LINK_MANAGER_DEFAULT_STATUS_CODE;
		$curl_handle = curl_init( $url );

		curl_setopt( $curl_handle, CURLOPT_RETURNTRANSFER, 1 );

		// Set common user agent.
		// @link https://www.useragents.me/#most-common-desktop-useragents
		curl_setopt( $curl_handle, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT'] ?? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36' );
		curl_setopt( $curl_handle, CURLOPT_TIMEOUT, 10 );

		$curl_exec = curl_exec( $curl_handle );

		if ( ! empty( $curl_exec ) ) {
			$http_code = curl_getinfo( $curl_handle, CURLINFO_HTTP_CODE );
		}

		curl_close( $curl_handle );

		if ( 403 === $http_code ) {
			$headers = @get_headers( $url );

			if ( $headers ) {
				$response_code = substr( $headers[0], 9, 3 );

				if ( is_numeric( $response_code ) ) {
					$http_code = $response_code;
				}
			}
		}
		// phpcs:enable

		$links_cache[ $url ] = [
			'updated_at' => $now,
			'status'     => $http_code,
		];

		update_option( SLIM_SEO_LINK_MANAGER_LINKS_CACHE_NAME, $links_cache );

		return $http_code;
	}

	public static function get_link_status_code( array $link ): int {
		$status_code = SLIM_SEO_LINK_MANAGER_DEFAULT_STATUS_CODE;

		if ( empty( $link['type'] ) ) {
			return $status_code;
		}

		if ( 'external' === $link['type'] ) {
			return self::get_http_code( $link['url'] );
		}

		if ( empty( $link['target_id'] ) || empty( $link['target_type'] ) ) {
			return self::get_http_code( self::get_full_url( $link['url'], $link ) );
		}

		if ( false !== stripos( $link['target_type'], 'tax:' ) ) {
			$term = get_term( $link['target_id'] );
			return empty( $term->term_id ) ? $status_code : 200;
		}

		$post = get_post( $link['target_id'] );
		return empty( $post->ID ) ? $status_code : 200;
	}

	public static function update_link_url( array $link, string $old_url, string $new_url ): array {
		if ( apply_filters( 'slim_seo_link_manager_ignore_update_link_url', false, $link, $old_url, $new_url ) ) {
			return $link;
		}

		$link['url']    = str_replace( $old_url, $new_url, $link['url'] );
		$link['status'] = self::get_link_status_code( $link );

		switch ( $link['location'] ) {
			case 'post_content':
				$post_content = get_post_field( 'post_content', $link['source_id'] );
				$post_content = str_replace( $old_url, $new_url, $post_content );

				wp_update_post( [
					'ID'           => $link['source_id'],
					'post_content' => $post_content,
				] );

				break;

			default:
				do_action( 'slim_seo_link_manager_update_link_url', $link, $old_url, $new_url );

				break;
		}

		$tbl_links = new Database\Links();
		$tbl_links->update( $link );

		return $link;
	}

	public static function get_posts( array $args = [] ): array {
		$posts = get_posts( array_merge( [
			'post_type'      => self::get_post_types(),
			'post_status'    => [ 'publish' ],
			'posts_per_page' => -1,
		], $args ) );

		return $posts;
	}

	public static function get_full_url( string $url, array $link = [] ): string {
		// If the URL only has slug
		if ( '/' === substr( $url, 0, 1 ) ) {
			$url = home_url( $url );
		} elseif ( '#' === substr( $url, 0, 1 ) && ! empty( $link['source_id'] ) ) {
			$url = trailingslashit( get_permalink( $link['source_id'] ) ) . $url;
		}

		return $url;
	}

	public static function set_scanner_running( bool $run = true ) {
		update_option( SLIM_SEO_LINK_MANAGER_IS_SCANNER_RUNNING, $run );
	}

	public static function is_scanner_running(): bool {
		return ! empty( get_option( SLIM_SEO_LINK_MANAGER_IS_SCANNER_RUNNING ) );
	}

	public static function get_total_scanned( string $name ): int {
		return intval( get_option( 'posts' === $name ? SLIM_SEO_LINK_MANAGER_TOTAL_SCANNED_POSTS : SLIM_SEO_LINK_MANAGER_TOTAL_SCANNED_LINKS ) );
	}

	public static function update_total_scanned( string $name, int $value ) {
		update_option( 'posts' === $name ? SLIM_SEO_LINK_MANAGER_TOTAL_SCANNED_POSTS : SLIM_SEO_LINK_MANAGER_TOTAL_SCANNED_LINKS, $value );
	}

	public static function background_processing_dispatch_post_args( array $args ): array {
		$args['timeout'] = 20;

		return $args;
	}

	public static function get_sql_condition_by_keyword( string $get, string $keyword ): string {
		global $wpdb;

		$condition = '';
		$keyword   = esc_sql( $keyword );

		switch ( $get ) {
			case 'linked_pages':
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$target_post_ids = $wpdb->get_col(
					"SELECT `ID`
					FROM {$wpdb->posts}
					WHERE `post_title` LIKE '%{$keyword}%'" // phpcs:ignore
				);

				if ( ! empty( $target_post_ids ) ) {
					$condition = ' AND `target_id` in ( ' . implode( ',', $target_post_ids ) . ' )';
				} else {
					$condition = '  AND `target_id` = -1';
				}

				break;

			case 'external_links':
				$condition = " AND `url` LIKE '%{$keyword}%'";

				break;

			case 'keywords':
				$condition = " WHERE `anchor_text` LIKE '%{$keyword}%'";

				break;
		}

		return $condition;
	}
}
