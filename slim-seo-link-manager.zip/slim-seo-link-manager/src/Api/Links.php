<?php
namespace SlimSEOPro\LinkManager\Api;

use SlimSEOPro\LinkManager\Database\Links as DbLinks;
use SlimSEOPro\LinkManager\Helper;
use WP_REST_Server;
use WP_REST_Request;

class Links extends Base {
	public function register_routes() {
		register_rest_route( 'slim-seo-link-manager', 'total_links', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_total_links' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'total_links_by_object', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_total_links_by_object' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'links_by_object', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_links_by_object' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'link_object_name', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_link_object_name' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'links_from_text', [
			'methods'             => WP_REST_Server::EDITABLE,
			'callback'            => [ $this, 'get_links_from_text' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'total_top_links', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_total_top_links' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'top_links', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_top_links' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'total_links_by_column_value', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_total_links_by_column_value' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'links_by_column_value', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'get_links_by_column_value' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'check_link_status', [
			'methods'             => WP_REST_Server::EDITABLE,
			'callback'            => [ $this, 'check_link_status' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );
	}

	public function get_total_links(): int {
		$tbl_links = new DbLinks();

		return $tbl_links->get_total() ?: -1;
	}

	public function get_total_links_by_object( WP_REST_Request $request ): int {
		$object_id   = $request->get_param( 'object_id' );
		$object_type = $request->get_param( 'object_type' );
		$type        = $request->get_param( 'type' );
		$tbl_links   = new DbLinks();

		return intval( $tbl_links->get_total_links_by_object( $object_id, $object_type, $type ) );
	}

	public function get_links_by_object( WP_REST_Request $request ): array {
		$object_id   = $request->get_param( 'object_id' );
		$object_type = $request->get_param( 'object_type' );
		$type        = $request->get_param( 'type' );
		$limit       = $request->get_param( 'limit' );
		$offset      = $request->get_param( 'offset' );
		$tbl_links   = new DbLinks();
		$links       = $tbl_links->get_links_by_object( $object_id, $object_type, $type, $limit, $offset );

		if ( empty( $links ) ) {
			return [];
		}

		$links = array_map( function ( $link ) use ( $type ) {
			$link = Helper::get_link_detail( $link, 'source' === $type ? 'target' : 'source' );

			if ( 'source' === $type ) {
				if ( ! empty( $link['target_id'] ) ) {
					$link['edit_link'] = false !== stripos( $link['target_type'], 'tax:' ) ? get_edit_term_link( $link['target_id'] ) : get_edit_post_link( $link['target_id'] );
				}
			} else {
				$link['edit_link'] = get_edit_post_link( $link['source_id'] );
			}

			$link['edit_link'] = ! empty( $link['edit_link'] ) ? $link['edit_link'] : '';

			return $link;
		}, $links );

		return $links;
	}

	public function get_link_object_name( WP_REST_Request $request ): string {
		$object_id   = $request->get_param( 'object_id' );
		$object_type = $request->get_param( 'object_type' );

		if ( false !== stripos( $object_type, 'tax:' ) ) {
			$term = get_term( $object_id );

			return html_entity_decode( $term->name ?? '' );
		} else {
			return html_entity_decode( get_the_title( $object_id ) ?? '' );
		}

		return '';
	}

	public function get_links_from_text( WP_REST_Request $request ): array {
		$post_links = $request->get_param( 'links' );

		if ( empty( $post_links ) ) {
			return [];
		}

		$source_id   = (int) $request->get_param( 'source_id' );
		$source_type = $request->get_param( 'source_type' );
		$location    = $request->get_param( 'location' );
		$links_cache = $request->get_param( 'linksCache' );
		$links       = Helper::get_links_from_text( implode( '', $post_links ), $source_id, $source_type, $location );

		foreach ( $links as $link_index => $link ) {
			$is_link_in_cache = false;

			foreach ( $links_cache as $link_cache ) {
				if ( $link_cache['url'] === $link['url'] ) {
					$is_link_in_cache = true;

					unset( $link_cache['nofollow'] );
					unset( $link_cache['anchor_text'] );

					$links[ $link_index ] = array_merge( $links[ $link_index ], $link_cache );

					break;
				}
			}

			if ( $is_link_in_cache ) {
				continue;
			}

			$link                        = Helper::get_link_detail( $link, 'target' );
			$link['should_check_status'] = $source_id === (int) $link['target_id'] && $source_type === $link['target_type'] ? 0 : 1;

			if ( ! empty( $link['target_id'] ) ) {
				$link['edit_link'] = false !== stripos( $link['target_type'], 'tax:' ) ? get_edit_term_link( $link['target_id'] ) : get_edit_post_link( $link['target_id'] );
				$link['edit_link'] = ! empty( $link['edit_link'] ) ? $link['edit_link'] : '';
			}

			$links[ $link_index ] = $link;
		}

		return $links;
	}

	public function get_total_top_links( WP_REST_Request $request ): int {
		$get            = $request->get_param( 'get' );
		$search_keyword = $request->get_param( 'searchKeyword' ) ?? '';
		$tbl_links      = new DbLinks();

		return intval( $tbl_links->get_total_top( $get, $search_keyword ) ?: -1 );
	}

	public function get_top_links( WP_REST_Request $request ): array {
		$get            = $request->get_param( 'get' );
		$limit          = intval( $request->get_param( 'limit' ) );
		$offset         = intval( $request->get_param( 'offset' ) );
		$search_keyword = $request->get_param( 'searchKeyword' );
		$tbl_links      = new DbLinks();
		$links          = $tbl_links->get_top( $get, $limit, $offset, $search_keyword );

		if ( in_array( $get, [ 'linked_pages', 'orphan_pages' ], true ) && ! empty( $links ) ) {
			$links = array_map( function ( $link ) {
				$link              = Helper::get_link_detail( $link, 'target' );
				$link['view_link'] = get_permalink( $link['target_id'] );
				$link['edit_link'] = get_edit_post_link( $link['target_id'] ) ?: '';

				return $link;
			}, $links );
		}

		return $links;
	}

	public function get_total_links_by_column_value( WP_REST_Request $request ): int {
		$column_name = $request->get_param( 'column_name' );
		$value       = $request->get_param( 'value' );
		$tbl_links   = new DbLinks();

		return intval( $tbl_links->get_total_links_by_column_value( $column_name, $value ) );
	}

	public function get_links_by_column_value( WP_REST_Request $request ): array {
		$column_name = $request->get_param( 'column_name' );
		$value       = $request->get_param( 'value' );
		$limit       = intval( $request->get_param( 'limit' ) );
		$offset      = intval( $request->get_param( 'offset' ) );
		$tbl_links   = new DbLinks();
		$links       = $tbl_links->get_links_by_column_value( $column_name, $value, $limit, $offset );

		if ( empty( $links ) ) {
			return [];
		}

		$links = array_map( function ( $link ) {
			$link              = Helper::get_link_detail( $link, 'all' );
			$link['edit_link'] = get_edit_post_link( $link['source_id'] ) ?: '';

			return $link;
		}, $links );

		return $links;
	}

	public function check_link_status( WP_REST_Request $request ): int {
		$link   = $request->get_param( 'link' );
		$status = Helper::get_link_status_code( $link );

		if ( ! empty( $link['id'] ) ) {
			$link['status'] = $status;

			unset( $link['should_check_status'] );
			unset( $link['target_name'] );
			unset( $link['edit_link'] );

			$tbl_links = new DbLinks;
			$tbl_links->update( $link );
		}

		return $status;
	}
}
