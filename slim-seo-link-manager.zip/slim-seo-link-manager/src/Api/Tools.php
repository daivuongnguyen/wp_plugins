<?php
namespace SlimSEOPro\LinkManager\Api;

use SlimSEOPro\LinkManager\Helper;
use SlimSEOPro\LinkManager\Database\Links as DbLinks;
use SlimSEOPro\LinkManager\BackgroundProcessing\PostsScanner;
use SlimSEOPro\LinkManager\Export;
use WP_REST_Server;
use WP_REST_Request;

class Tools extends Base {
	public function register_routes() {
		register_rest_route( 'slim-seo-link-manager', 'check_links_scanner_is_running', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'check_links_scanner_is_running' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'links_scanner', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'links_scanner' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'total_links_searched_by_url', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'total_links_searched_by_url' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'prepare_link_updater', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'prepare_link_updater' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'link_updater', [
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => [ $this, 'link_updater' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );

		register_rest_route( 'slim-seo-link-manager', 'export_csv', [
			'methods'             => WP_REST_Server::EDITABLE,
			'callback'            => [ $this, 'export_csv' ],
			'permission_callback' => [ $this, 'has_permission' ],
		] );
	}

	public function check_links_scanner_is_running(): bool {
		return Helper::is_scanner_running();
	}

	public function links_scanner(): bool {
		$posts_scanner = new PostsScanner();
		$posts         = Helper::get_posts( [ 'fields' => 'ids' ] );

		if ( empty( $posts ) ) {
			return true;
		}

		Helper::update_total_scanned( 'posts', 0 );
		Helper::update_total_scanned( 'links', 0 );

		update_option( SLIM_SEO_LINK_MANAGER_TOTAL_POSTS, count( $posts ) );

		Helper::set_scanner_running();

		$tbl_links = new DbLinks();
		$tbl_links->truncate();

		foreach ( $posts as $post_id ) {
			$posts_scanner->push_to_queue( $post_id );
		}

		$posts_scanner->save()->dispatch();

		return true;
	}

	public function total_links_searched_by_url( WP_REST_Request $request ): int {
		$url       = $request->get_param( 'url' );
		$tbl_links = new DbLinks();
		$links     = $tbl_links->search_links_by_url( $url );

		return count( $links );
	}

	public function prepare_link_updater(): bool {
		if ( PHP_SESSION_NONE === session_status() ) {
			session_start();
		}

		$_SESSION['processed_ids'] = [];

		return true;
	}

	public function link_updater( WP_REST_Request $request ): array {
		if ( PHP_SESSION_NONE === session_status() ) {
			session_start();
		}

		$old_url   = $request->get_param( 'old_url' );
		$new_url   = $request->get_param( 'new_url' );
		$tbl_links = new DbLinks();
		$links     = $tbl_links->search_links_by_url( $old_url, 1, array_map( 'intval', $_SESSION['processed_ids'] ?? [] ) );

		if ( ! empty( $links ) ) {
			$link     = $links[0];
			$link_url = $link['url'];
			$link     = Helper::update_link_url( $link, $old_url, $new_url );

			$_SESSION['processed_ids'][] = $link['id'];

			return [
				'message' => sprintf(
					// Translators: %1$s - source link, %2$s - destination link
					__( 'Updated link %1$s in %2$s', 'slim-seo-link-manager' ),
					$link_url,
					'<a href="' . get_permalink( $link['source_id'] ) . '" target="_blank">' . get_the_title( $link['source_id'] ) . '</a>'
				),
				'type'    => 'continue',
			];
		} else {
			$_SESSION['processed_ids'] = [];

			return [
				'message' => __( 'Done!', 'slim-seo-link-manager' ),
				'type'    => 'done',
			];
		}
	}

	public function export_csv( WP_REST_Request $request ) {
		$report = $request->get_param( 'report' );
		$args   = $request->get_param( 'args' ) ?? [];
		$result = Export::get_csv_data( $report, $args );

		return $result;
	}
}
