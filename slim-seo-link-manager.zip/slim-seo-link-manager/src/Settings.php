<?php
namespace SlimSEOPro\LinkManager;

class Settings {
	public function __construct() {
		add_filter( 'slim_seo_settings_tabs', [ $this, 'add_tab' ] );
		add_filter( 'slim_seo_settings_panes', [ $this, 'add_pane' ] );
		add_action( 'admin_print_styles-settings_page_slim-seo', [ $this, 'enqueue' ] );

		add_filter( 'slim_seo_upgradeable', '__return_false' );
	}

	public function add_tab( array $tabs ): array {
		$tabs['link-manager'] = __( 'Link Manager', 'slim-seo-link-manager' );
		return $tabs;
	}

	public function add_pane( array $panes ): array {
		$panes['link-manager'] = '<div id="link-manager" class="ss-tab-pane"><div id="sslm-dashboard"></div></div>';
		return $panes;
	}

	public function enqueue() {
		wp_enqueue_style( 'slim-seo-settings', 'https://cdn.jsdelivr.net/gh/elightup/slim-seo@master/css/settings.min.css', [], SLIM_SEO_LINK_MANAGER_VER );
		wp_enqueue_script( 'slim-seo-settings', 'https://cdn.jsdelivr.net/gh/elightup/slim-seo@master/js/settings.min.js', [], SLIM_SEO_LINK_MANAGER_VER, true );

		wp_enqueue_style( 'slim-seo-react-tabs', 'https://cdn.jsdelivr.net/gh/elightup/slim-seo@master/css/react-tabs.min.css', [], SLIM_SEO_LINK_MANAGER_VER );

		wp_enqueue_style( 'slim-seo-link-manager', SLIM_SEO_LINK_MANAGER_URL . 'css/link-manager.css', [ 'wp-components' ], filemtime( SLIM_SEO_LINK_MANAGER_DIR . '/css/link-manager.css' ) );

		wp_enqueue_script( 'slim-seo-link-manager-dashboard', SLIM_SEO_LINK_MANAGER_URL . 'js/dashboard.js', [ 'wp-element', 'wp-components', 'wp-i18n' ], filemtime( SLIM_SEO_LINK_MANAGER_DIR . '/js/dashboard.js' ), true );

		$localized_data = [
			'rest'            => untrailingslashit( rest_url() ),
			'nonce'           => wp_create_nonce( 'wp_rest' ),
			'settingsPageURL' => untrailingslashit( admin_url( 'options-general.php?page=slim-seo' ) ),
			'tabID'           => 'link-manager',
		];

		wp_localize_script( 'slim-seo-link-manager-dashboard', 'SSLinkManager', $localized_data );

		do_action( 'slim_seo_link_manager_enqueue' );
		do_action( 'slim_seo_link_manager_enqueue_settings' );
	}
}
