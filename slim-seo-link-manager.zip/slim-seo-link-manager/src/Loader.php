<?php
namespace SlimSEOPro\LinkManager;

use SlimSEO\Settings\Page;
use SlimSEO\Updater\Tab;
use eLightUp\PluginUpdater\Manager;
use SlimSEO\Updater\Settings as UpdaterSettings;
use SlimSEOPro\LinkManager\BackgroundProcessing\PostsScanner;
use SlimSEOPro\LinkManager\BackgroundProcessing\LinksScanner;
use SlimSEOPro\LinkManager\BackgroundProcessing\LinkUpdater;
use SlimSEOPro\LinkManager\BackgroundProcessing\CheckLinkStatus;
use SlimSEOPro\LinkManager\LinkSuggestions\Controller;

class Loader {
	public function init() {
		if ( is_admin() ) {
			// Create custom table
			$this->create_table();

			// Setup settings page
			Page::setup();
			new Settings;

			new CustomFields;
			new Shortcodes;
			new Misc;

			new Post;

			new Notices;

			// Updater
			$this->updater();
		}

		// Integrations
		new Integrations\Bricks;
		new Integrations\Oxygen;
		new Integrations\Elementor;
		new Integrations\Divi;
		new Integrations\TablePress;

		// Background Processing
		new PostsScanner;
		new LinksScanner;
		new LinkUpdater;
		new CheckLinkStatus;

		// Load APIs
		new Api\Links;
		new Api\Tools;

		$suggestion_controller = new Controller;
		$suggestion_api        = new LinkSuggestions\Api;
		$suggestion_api->set_controller( $suggestion_controller );
	}

	private function create_table() {
		$option_name = 'sslm_db_version';
		$db_version  = get_option( $option_name );

		if ( $db_version < SLIM_SEO_LINK_MANAGER_VER ) {
			$table = new Database\Table();

			$table->create_ss_links_table();

			update_option( $option_name, SLIM_SEO_LINK_MANAGER_VER );
		}
	}

	private function updater() {
		if ( defined( 'SLIM_SEO_PRO_VER' ) ) {
			return;
		}
		Tab::setup();
		$manager           = new Manager( [
			'api_url'            => 'https://wpslimseo.com/index.php',
			'my_account_url'     => 'https://wpslimseo.com/my-account/',
			'buy_url'            => 'https://wpslimseo.com/slim-seo-link-manager/',
			'slug'               => 'slim-seo-link-manager',
			'settings_page'      => admin_url( 'options-general.php?page=slim-seo#license' ),
			'settings_page_slug' => 'slim-seo',
		] );
		$settings          = new UpdaterSettings( $manager, $manager->checker, $manager->option );
		$manager->settings = $settings;
		$manager->setup();
	}
}
