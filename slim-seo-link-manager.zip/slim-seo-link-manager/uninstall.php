<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || die;

delete_option( 'sslm_links_cache' );
delete_option( 'sslm_db_version' );
delete_option( 'slim_seo_link_manager_total_posts' );
delete_option( 'slim_seo_link_manager_total_links' );
delete_option( 'slim_seo_link_manager_is_scanner_running' );
delete_option( 'slim_seo_link_manager_total_scanned_posts' );
delete_option( 'slim_seo_link_manager_total_scanned_links' );

global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}slim_seo_links" );
