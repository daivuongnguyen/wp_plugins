<?php
/**
 * Plugin Name: Slim SEO Link Manager
 * Plugin URI:  https://wpslimseo.com
 * Description: A link manager plugin for WordPress.
 * Author:      eLightUp
 * Author URI:  https://elightup.com
 * Version:     1.6.4
 * Text Domain: slim-seo-link-manager
 * Domain Path: /languages/
 */

namespace SlimSEOPro\LinkManager;

defined( 'ABSPATH' ) || die;

define( 'SLIM_SEO_LINK_MANAGER_DIR', __DIR__ );
define( 'SLIM_SEO_LINK_MANAGER_URL', plugin_dir_url( __FILE__ ) );
define( 'SLIM_SEO_LINK_MANAGER_VER', '1.6.4' );
define( 'SLIM_SEO_LINK_MANAGER_IS_SCANNER_RUNNING', 'slim_seo_link_manager_is_scanner_running' );
define( 'SLIM_SEO_LINK_MANAGER_TOTAL_POSTS', 'slim_seo_link_manager_total_posts' );
define( 'SLIM_SEO_LINK_MANAGER_TOTAL_LINKS', 'slim_seo_link_manager_total_links' );
define( 'SLIM_SEO_LINK_MANAGER_TOTAL_SCANNED_POSTS', 'slim_seo_link_manager_total_scanned_posts' );
define( 'SLIM_SEO_LINK_MANAGER_TOTAL_SCANNED_LINKS', 'slim_seo_link_manager_total_scanned_links' );
define( 'SLIM_SEO_LINK_MANAGER_DEFAULT_STATUS_CODE', 200 );
define( 'SLIM_SEO_LINK_MANAGER_LINKS_CACHE_NAME', 'sslm_links_cache' );

if ( file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
	require __DIR__ . '/vendor/autoload.php';
}

$slim_seo_link_manager_loader = new Loader();
$slim_seo_link_manager_loader->init();

new Activator;
new Deactivator( __FILE__ );
