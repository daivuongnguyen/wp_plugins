<?php
/*
Plugin Name: Markdown to HTML Converter
Description: Tự động chuyển Markdown thành HTML khi lưu bài viết (dùng Parsedown)
Version: 1.0
Author: Vincent
*/

if (!defined('ABSPATH')) exit;

// Auto-load Parsedown khi cần
require_once plugin_dir_path(__FILE__) . 'Parsedown.php';

// Hàm xử lý chuyển markdown sang html khi lưu bài
function markdown_to_html_on_save($data, $postarr) {
    // Chỉ áp dụng cho post và page, và loại bỏ nếu đang soạn thảo dạng HTML
    if (!empty($data['post_content'])) {
        $parsedown = new Parsedown();

        // Xoá footnote kiểu [^1], [^note], [1], [note], v.v.
        $content = preg_replace('/\[\^?[^\]]+\]/', '', $data['post_content']);

        // Loại bỏ các ký tự escape markdown: \& \$ \% \_ v.v.
        $content = preg_replace('/\\\\([$\&%\_\-\.\,])/', '$1', $content);

        // Convert Markdown sang HTML
        $content = $parsedown->text($content);

        // Gán lại vào nội dung post
        $data['post_content'] = $content;
    }
    return $data;
}
add_filter('wp_insert_post_data', 'markdown_to_html_on_save', 12, 2);

