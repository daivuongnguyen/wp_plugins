<?php

namespace ExactLinksPro\App\Services;

use ExactLinks\App\Helpers\Shortner;

class ABLinkCreation
{
    public static function handleAbLinkCreation($request, $link)
    {
        $title          = sanitize_text_field($request->get('title'));
        $abLinks        = wp_unslash($request->get('ab_links'));
        $slug           = sanitize_title($request->get('slug'));
        $tags           = wp_unslash($request->get('tags'));
        $globalSettings = get_option('exactlinks_settings');

        $data = [
            'type'            => 'ab_pages',
            'slug'            => $slug,
            'title'           => $title,
            'redirect_type'   => $globalSettings['redirection'] ? intval($globalSettings['redirection']) : 307,
            'tags'            => maybe_serialize($tags),
            'created_at'      => gmdate('Y-m-d H:i:s'),
            'updated_at'      => gmdate('Y-m-d H:i:s'),
            'last_link_check' => gmdate('Y-m-d H:i:s'),
            'author_id'       => get_current_user_id()
        ];

        $abLinkId = $link->insertGetId($data);

        foreach ($abLinks as $linkIndex => $ab_link) {
            $abLinkData = [
                'type'            => 'ab_links',
                'slug'            => sanitize_title((new Shortner)->getSlug()),
                'parent_id'       => $abLinkId,
                'priority'        => intval($ab_link['priority']),
                'author_id'       => get_current_user_id(),
                'status'          => 'active',
                'target_url'      => sanitize_url($ab_link['target_url']),
                'target_domain'   => $link->getDomainByUrl(sanitize_url($ab_link['target_url'])),
                'redirect_type'   => $globalSettings['redirection'] ? intval($globalSettings['redirection']) : 307,
                'created_at'      => gmdate('Y-m-d H:i:s'),
                'updated_at'      => gmdate('Y-m-d H:i:s'),
                'last_link_check' => gmdate('Y-m-d H:i:s')
            ];
            
            $link->insert($abLinkData);
        }

        return $abLinkId;
    }
}


