<?php

/**
 * @var $router ExactLinks\Framework\Http\Router
 */

$router->prefix('global_settings')->withPolicy('AdminPolicy')->group(function ($router) {
    $router->get('license', '\ExactLinksPro\App\Http\Controllers\LicenseController@getStatus');
    $router->post('license', '\ExactLinksPro\App\Http\Controllers\LicenseController@saveLicense');
    $router->delete('license', '\ExactLinksPro\App\Http\Controllers\LicenseController@deactivateLicense');
});