<?php 

defined('ABSPATH') or die;

/*
Plugin Name: Exact Links Pro
Plugin URI: https://wordpress.org/plugins/exact-links/
Description: The Most Sophisticated URL Shortener And Conversion Tracking For WordPress  
Version: 2.0.0
Author: ExactLinks
Author URI: https://exactlinks.com
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: exact-links-pro
Domain Path: /language
*/

if (defined('EXACTLINKSPRO_DIR_FILE')) {
    return;
}

define('EXACTLINKSPRO_DIR_FILE', __FILE__);


require_once("exact-links-boot.php");

add_action('exactlinks_loaded', function ($app) {
    (new \ExactLinksPro\App\Application($app));
    do_action('exactlinks_pro_loaded', $app);
});


add_action('init', function () {
    load_plugin_textdomain('exact-links-pro', false, dirname(plugin_basename(__FILE__)) . '/languages');
});


add_action('plugins_loaded', function () {
    $licenseManager = new \ExactLinksPro\App\Services\PluginManager\LicenseManager();
    $licenseManager->initUpdater();
    $licenseMessage = $licenseManager->getLicenseMessages();

    if ($licenseMessage) {
        add_action('admin_notices', function () use ($licenseMessage) {
            if (defined('EXACTLINKS')) {
                $class = 'notice notice-error ex_message';
                $message = $licenseMessage['message'];
                printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), $message);
            }
        });
    }
}, 0);