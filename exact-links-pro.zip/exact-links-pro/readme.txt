=== Exact Links Pro  ===
Contributors: rupok98, ruhel241
Tags: url shortener, Exact Links, Short URL, WooCommerce Conversion Tracking, A/B Split Testing, Choice Page, link cloaking, shorten amazon link, affiliate link shortener, Link Management, WordPress AB testing, wordpress a/b testing, WordPress split test plugin
Requires at least: 5.0
Tested up to: 6.0 
Requires PHP: 5.6
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Simple Links ==
Exact Links comes with a simple URL shortener feature. You can easily convert your long ugly URL to a custom beautiful URL. This simple short  URL feature also tracks clicks and conversion with detailed analytical reports.

* You can create beautiful and customized  short URL from long boring URL
* You can  affiliate links cloaking 
* You can understand each short URL link performance  [ Trand ,Conversion Rate ,Net Sales for WooCommerce ] 
* Complete analytics with traffic source,  device name, browser, OS
* Understand from which traffic source your visitors are coming 
* Track clicks and number of  unique clicks 
* Provides a reporting interface where you can see a configurable chart of clicks, unique clicks and conversion per day. This report can be filtered by specific date range. 

== Box Content  [ Generate Awesome Designed  Content ] ==
This awesome feature comes with the Exact Links plugin. WordPress users  can generate awesome looking landing pages easily by this feature. This feature comes with different eye-catching web templates and also WordPress users can customize each design.

* Create awesome looks  product box template in a click 
* Compatible with gutenberg editor 
* 6 different template design  which also can be customize 
* Detailed conversion and click analytics report 
* Conversion tracking for Woocommerce Store 
* Short code available 

== Choice Page ==
Build your page in seconds with product suggestions. Choice Pages don't just help your audience by giving multiple choices. It also lets you know which option is converting the most. You can test alternative names, titles, featured images, and descriptions for your products, and use your orders as conversion actions. 

* Beautiful choices Built in seconds 
* Understand which choice button option is most popular 
* Clear Insight  which option is converting most  [ WooCommerce ]
* Custom beautiful slag for choice page 
* 2 Different choice page design 
* Understand from which traffic source customers are coming 
* Compare Conversion With Different Option  [ WooCommerce ]


== WordPress A/B Testing ==
Exact Links plugin automatically splits traffic to different landing pages based on your priority setting and also tracks the conversion rate for each landing page .This A/B Testing feature is most sophisticated and easy to use.

* A/B Split allows users to Split Traffic to different landing pages based on priority.
* A/B Split allows users to Understand which landing page is converting well [ WooCommerce ]
* A/B Split allows users to  understand device type, device brand, device name, browser, OS for landing pages 
* A/B Split allows users  to understand from which traffic source customers are coming 
* Track clicks and number of  unique clicks 
* Provides a reporting interface where you can see a configurable chart of clicks, unique clicks and conversion rate. This report can be filtered by the specific link clicked, date range, and/or unique clicks.  

== Global Setting ==
* Select Temporary (302 or 307) or Permanent (301) redirection for your short links 
* Cookie based system for tracking visitor activity across clicks. you also can set Cookie time.
* You can set slug character length for your automated  short links.
* You can add your google analytics code. 


== Screenshots ==
1. Simple Short Link 
2. Box Content
3. Choice Page
4. A/B Split
5. Setting Page
6. Dashboard
7. Analytics
8. Exact links select template Guten block 
9. Exact Links Guten Block

== Changelog ==

= 2.0.0 =
* Fix Exact Links Pro License

= 1.0.0 =
* Init First version

== Upgrade Notice ==