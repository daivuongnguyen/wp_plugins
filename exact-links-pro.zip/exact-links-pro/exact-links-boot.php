<?php

!defined('WPINC') && die;

define('EXACTLINKSPRO', 'exactlinkspro');
define('EXACTLINKSPRO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('EXACTLINKSPRO_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('EXACTLINKSPRO_PLUGIN_VERSION', '2.0.0');

spl_autoload_register(function ($class) {

    $match = 'ExactLinksPro';
    if (!preg_match("/\b{$match}\b/", $class)) {
        return;
    }

    $path = plugin_dir_path(__FILE__);

    $file = str_replace(
        ['ExactLinksPro', '\\', '/App/'],
        ['', DIRECTORY_SEPARATOR, 'app/'],
        $class
    );
    
    require(trailingslashit($path) . trim($file, '/') . '.php');
});


class ExactLinksPro_Dependency
{
    public function init()
    {
        $this->injectDependency();
    }

    /**
     * Notify the user about the ExactLinks dependency and instructs to install it.
     */
    protected function injectDependency()
    {
        add_action('admin_notices', function () {
            $pluginInfo = $this->getInstallationDetails();

            $class = 'notice notice-error';

            $install_url_text = 'Click Here to Install the Plugin';

            if ($pluginInfo->action == 'activate') {
                $install_url_text = 'Click Here to Activate the Plugin';
            }

            $message = 'Exact Links Pro Add-On Requires Exact Links Base Plugin, <b><a href="' . $pluginInfo->url
                . '">' . $install_url_text . '</a></b>';

            printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), $message);
        });
    }

    /**
     * Get the ExactLinks plugin installation information e.g. the URL to install.
     *
     * @return \stdClass $activation
     */
    protected function getInstallationDetails()
    {
        $activation = (object)[
            'action' => 'install',
            'url'    => ''
        ];

        $allPlugins = get_plugins();

        if (isset($allPlugins['exact-links/exact-links.php'])) {
            $url = wp_nonce_url(
                self_admin_url('plugins.php?action=activate&plugin=exact-links/exact-links.php'),
                'activate-plugin_exact-links/exact-links.php'
            );
            
            $activation->action = 'activate';
        } else {
            $api = (object)[
                'slug' => 'exact-links'
            ];

            $url = wp_nonce_url(
                self_admin_url('update.php?action=install-plugin&plugin=' . $api->slug),
                'install-plugin_' . $api->slug
            );
        }

        $activation->url = $url;

        return $activation;
    }
}

add_action('init', function () {
    if (!defined('EXACTLINKS')) {
        (new ExactLinksPro_Dependency())->init();
    }
});