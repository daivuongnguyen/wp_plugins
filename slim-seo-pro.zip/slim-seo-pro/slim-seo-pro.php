<?php
/**
 * Plugin Name: Slim SEO Pro
 * Plugin URI:  https://wpslimseo.com/pro/
 * Description: An all-in-one premium SEO plugin for WordPress.
 * Author:      eLightUp
 * Author URI:  https://elightup.com
 * Version:     1.0.2
 * Text Domain: slim-seo
 * Domain Path: /languages
 */

namespace SlimSEOPro;

use SlimSEO\Updater\Tab;
use eLightUp\PluginUpdater\Manager;
use SlimSEO\Updater\Settings as UpdaterSettings;

defined( 'ABSPATH' ) || die;

define( 'SLIM_SEO_PRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'SLIM_SEO_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'SLIM_SEO_PRO_VER', '1.0.2' );

require __DIR__ . '/vendor/autoload.php';

require __DIR__ . '/vendor/elightup/slim-seo-schema/slim-seo-schema.php';
require __DIR__ . '/vendor/elightup/slim-seo-link-manager/slim-seo-link-manager.php';

new Activator();
new Settings();

if ( is_admin() ) {
	// Updater.
	Tab::setup();
	$manager           = new Manager( [
		'api_url'            => 'https://wpslimseo.com/index.php',
		'my_account_url'     => 'https://wpslimseo.com/my-account/',
		'buy_url'            => 'https://wpslimseo.com/products/slim-seo-pro/',
		'slug'               => 'slim-seo-pro',
		'settings_page'      => admin_url( 'options-general.php?page=slim-seo#license' ),
		'settings_page_slug' => 'slim-seo',
	] );
	$settings          = new UpdaterSettings( $manager, $manager->checker, $manager->option );
	$manager->settings = $settings;
	$manager->setup();
}
