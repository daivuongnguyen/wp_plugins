<?php
namespace SlimSEOPro;

class Settings {
	public function __construct() {
		add_filter( 'slim_seo_link_manager_plugin_warning_messages', [ $this, 'plugin_warning_messages' ] );
		add_filter( 'slim_seo_schema_plugin_warning_messages', [ $this, 'plugin_warning_messages' ] );
		add_filter( 'slim_seo_link_manager_manager_args', [ $this, 'manager_args' ] );
		add_filter( 'slim_seo_schema_manager_args', [ $this, 'manager_args' ] );
		add_filter( 'elightup_plugin_updater_disallow_setup', [ $this, 'disallow_setup' ], 10, 2 );
	}

	public function plugin_warning_messages( $messages ) {
		$messages = [
			// Translators: %1$s - URL to the settings page.
			'no_key'  => __( 'You have not set your Slim SEO Pro license key yet. Please <a href="%1$s" target="_blank">enter your license key</a> to continue.', 'slim-seo-pro' ),
			// Translators: %1$s - URL to the settings page.
			'invalid' => __( 'Your license key for Slim SEO Pro is <b>invalid</b>. Please <a href="%1$s" target="_blank">enter your license key</a> to continue.', 'slim-seo-pro' ),
			// Translators: %1$s - URL to the settings page.
			'error'   => __( 'Your license key for Slim SEO Pro is <b>invalid</b>. Please <a href="%1$s" target="_blank">enter your license key</a> to continue.', 'slim-seo-pro' ),
			// Translators: %2$s - URL to the My Account page.
			'expired' => __( 'Your license key for Slim SEO Pro is <b>expired</b>. Please <a href="%2$s" target="_blank">renew your license</a> to continue.', 'slim-seo-pro' ),
		];

		return $messages;
	}

	public function manager_args( $args ) {
		$args['plugin_id'] = $args['slug'];
		$args['buy_url']   = 'https://wpslimseo.com/products/slim-seo-pro/';
		$args['slug']      = 'slim-seo-pro';

		return $args;
	}

	public function disallow_setup( $disallow, $plugin_id ) {
		if ( in_array( $plugin_id, [ 'slim-seo-link-manager', 'slim-seo-schema' ], true ) ) {
			$disallow = true;
		}

		return $disallow;
	}
}
