### 1.0.2 - 2025-04-17

Fix compatibility with Litespeed Cache plugin

### 1.0.1 - 2025-04-11

- Replace Twig lib with a much lighter lib to improve performance
- Article schema: remove name, isPartOf, mainEntity; replace description with articleBody; make props optional
- BreadcrumbList schema: add current page as the last item
- Movie schema: add genre prop
- Person schema: fix missing id if that's not the current author/user.
- JSON-LD schema: make value of prop accept null/true/false
- Improve scrolling to text in link suggestions
- Fix nullable warning in PHP 8.4

### 1.0.0 - 2025-04-04

First release