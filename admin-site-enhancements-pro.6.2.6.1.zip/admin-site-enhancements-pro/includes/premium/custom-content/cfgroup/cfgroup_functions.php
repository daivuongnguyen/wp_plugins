<?php

function get_cf( $field_name = false, $output_format = 'default', $post_id = false ) {
    
    // Normalizing for getting all field values
    if ( false == $field_name || 'all' == $field_name ) {
        $field_name = false; 
    }
    
    // For CSS class naming in custom field output
    $field_name_slug = str_replace( '_', '-', $field_name );

    // Get post ID
    global $post;        
    if ( false === $post_id ) {
        $post_id = ( ! empty( $post-> ID ) ) ? $post->ID : get_the_ID();
    }

    // Get custom field info
    $cf_info = CFG()->get_field_info( $field_name, $post_id );
    $cf_type = isset( $cf_info['type'] ) ? $cf_info['type'] : 'text';

    // Set the base format when getting CFG()->get() return value
    if ( 'default' == $output_format ) {
    	$base_format = 'api';
    } elseif ( 'raw' == $output_format) {
        $base_format = 'raw';           
    } else {
    	if ( 'select' == $cf_type ) {
    		// So we get the option values and labels intact and not as an indexed array
	    	$base_format = 'api';		
    	} else {
	    	$base_format = 'raw';
    	}
    }
    
    // Get the value of custom field
    $options = array( 'format' => $base_format );
    $cf_value = CFG()->get( $field_name, $post_id, $options );

    // Process custom field value further
            
    if ( 'text' == $cf_type || 'textarea' == $cf_type || 'wysiwyg' == $cf_type || 'color' == $cf_type ) {

    	if ( 'default' == $output_format || 'raw' == $output_format ) {
	    	return $cf_value;		
    	}

    } elseif ( 'true_false' == $cf_type ) {

    	if ( 'default' == $output_format ) {
			return ( 1 == $cf_value ) ? true : false;
		}

    	if ( 'raw' == $output_format ) {
			return $cf_value;
		}
		
    	if ( 'yes_no' == $output_format ) {
			return ( 1 == $cf_value ) ? 'Yes' : 'No';
		}
		
    } elseif ( 'select' == $cf_type ) {

		// Return array
    	if ( 'default' == $output_format || 'raw' == $output_format ) {
    		return $cf_value;
    	}

    	// Return comma separated labels (array values)
    	if ( 'values_c' == $output_format || 'labels' == $output_format ) {

	    	$values = array_values( $cf_value );

	    	if ( count( $values ) > 1 ) {
				return implode( ', ', $values );
	    	} else {
				return $values[0];
	    	}

    	}

        // Return comma separated values (array keys)
        if ( 'keys_c' == $output_format || 'values' == $output_format ) {

            $keys = array_keys( $cf_value );

            if ( count( $keys ) > 1 ) {
                return implode( ', ', $keys );
            } else {
                return $keys[0];
            }

        }

    } elseif ( 'date' == $cf_type ) {
    	
    	if ( 'default' == $output_format || 'raw' == $output_format ) {
    		return $cf_value;
    	} else {
    		return wp_date( $output_format, strtotime( $cf_value ) );
    	}
    	
    } elseif ( 'hyperlink' == $cf_type ) {
    	
    	if ( 'default' == $output_format || 'raw' == $output_format ) {
	    	return $cf_value;		
    	}
    	
    } elseif ( 'file' === $cf_type ) {
    	
    	$file_type = $cf_info['options']['file_type'];
    	$return_value = $cf_info['options']['return_value'];
    	
    	if ( 'image' === $file_type ) {
    		
	     	// Output attachment ID
	    	if ( 'default' == $output_format || 'raw' == $output_format ) {
	    		return $cf_value;
	    	}
	    	
	        // Output image URL
	        if ( false !== strpos( $output_format, 'image_url' ) ) {
	            $image_size = str_replace( 'image_url__', '', $output_format );
	            return wp_get_attachment_image_url( $cf_value, $image_size );
	        }

	        // Output actual image
	        if ( false !== strpos( $output_format, 'image_view' ) ) {
	            $image_size = str_replace( 'image_view__', '', $output_format );
	            return '<img src="' . wp_get_attachment_image_url( $cf_value, $image_size ) . '" class="' . esc_attr( $field_name_slug ) . ' ' . esc_attr( $image_size ) . '"/>';                    
	        }

    	}

    	if ( 'video' === $file_type ) {

	     	// Output attachment ID
	    	if ( 'default' == $output_format || 'raw' == $output_format ) {
	    		return $cf_value;
	    	}

	     	// Output video player. $cf_value will be the attachment ID with a custom output of 'video_player'.
	    	if ( 'video_player' == $output_format ) {
	    		$file_url = wp_get_attachment_url( $cf_value );
	    		return do_shortcode( '[video src="' . $file_url . '"]' ) . 
                '<style>
                .wp-video, video.wp-video-shortcode, .mejs-container.mejs-video, .mejs-overlay.load {
                    width: 100% !important;
                    height: 100% !important;
                }
                .mejs-container.mejs-video {
                    padding-top: 56.25%;
                }
                .wp-video, video.wp-video-shortcode {
                    max-width: 100% !important;
                }
                video.wp-video-shortcode {
                    position: relative;
                }
                .mejs-video .mejs-mediaelement {
                    position: absolute;
                    top: 0;
                    right: 0;
                    bottom: 0;
                    left: 0;
                }
                .mejs-video .mejs-controls {
                    /* display: none; */
                }
                .mejs-video .mejs-overlay-play {
                    top: 0;
                    right: 0;
                    bottom: 0;
                    left: 0;
                    width: auto !important;
                    height: auto !important;
                }
                </style>';
	    	}
    		    		
    	}

    	if ( 'audio' === $file_type ) {

	     	// Output attachment ID
	    	if ( 'default' == $output_format || 'raw' == $output_format ) {
	    		return $cf_value;
	    	}

	     	// Output audio player. $cf_value will be the attachment ID with a custom output of 'audio_player'.
	    	if ( 'audio_player' == $output_format ) {
	    		$file_url = wp_get_attachment_url( $cf_value );
	    		return do_shortcode( '[audio src="' . $file_url . '"]' );
	    	}

	    }

    	if ( 'pdf' === $file_type ) {

	     	// Output attachment ID
	    	if ( 'default' == $output_format || 'raw' == $output_format ) {
	    		return $cf_value;
	    	}

	     	// Output audio player. $cf_value will be the attachment ID with a custom output of 'audio_player'.
	    	if ( 'pdf_viewer' == $output_format ) {
	    		$file_url = wp_get_attachment_url( $cf_value );
	    		$random_number = rand(1,1000);
	    		return '<div id="pdf-viewer-'. $random_number .'" class="pdfobject-viewer"></div>
	    				<style>
						.pdfobject-container { width: 48rem; height: 32rem; border: 1rem solid rgba(0,0,0,.1); }
                        @media screen and (max-width: 768px) {
                            .pdfobject-container { width: 100%; height: 32rem; }
                        }
						</style>
	    				<script src="' . ASENHA_URL . 'assets/premium/js/pdfobject.js"></script>
	    				<script>PDFObject.embed("' . $file_url . '", "#pdf-viewer-'. $random_number .'");</script>';
	    	}

    	}

    	if ( 'any' === $file_type ) {

	     	// Output attachment ID
	    	if ( 'default' == $output_format || 'raw' == $output_format ) {
	    		return $cf_value;
	    	}

	    }

    } elseif ( 'term' == $cf_type ) {
        
        if ( 'default' == $output_format || 'raw' == $output_format ) {
            return $cf_value;       
        }
        
        if ( 'names' == $output_format ) {
            if ( is_array( $cf_value ) && count( $cf_value ) > 0 ) {
                $names = array();
                foreach( $cf_value as $term_id ) {
                    $term_id = (int) $term_id;
                    $term = get_term( $term_id );
                    $names[] = $term->name;
                }
                $names = implode(', ', $names );
                return $names;
            } else {
                return '';
            }
        }

        if ( 'names_archive_links' == $output_format ) {
            if ( is_array( $cf_value ) && count( $cf_value ) > 0 ) {
                $names_archive_links = array();
                foreach( $cf_value as $term_id ) {
                    $term_id = (int) $term_id;
                    $term = get_term( $term_id );
                    $names_archive_links[] = '<a href="' . get_term_link( $term_id ) . '">' . $term->name . '</a>';
                }
                $names_archive_links = implode(', ', $names_archive_links );
                return $names_archive_links;
            } else {
                return '';
            }
        }
        
        if ( 'names_edit_links' == $output_format ) {
            if ( is_array( $cf_value ) && count( $cf_value ) > 0 ) {
                $names_edit_links = array();
                foreach( $cf_value as $term_id ) {
                    $term_id = (int) $term_id;
                    $term = get_term( $term_id );
                    $names_edit_links[] = '<a href="' . get_edit_term_link( $term_id ) . '">' . $term->name . '</a>';
                }
                $names_edit_links = implode(', ', $names_edit_links );
                return $names_edit_links;
            } else {
                return '';
            }
        }
        
    } elseif ( 'user' == $cf_type ) {
        
        if ( 'default' == $output_format || 'raw' == $output_format ) {
            return $cf_value;       
        }
        
        if ( 'first_names' == $output_format ) {
            if ( is_array( $cf_value ) && count( $cf_value ) > 0 ) {
                $first_names = array();
                foreach( $cf_value as $user_id ) {
                    $user_id = (int) $user_id;
                    $user = get_user_by( 'id', $user_id );
                    $first_names[] = $user->user_firstname;
                }
                $first_names = implode(', ', $first_names );
                return $first_names;
            } else {
                return '';
            }
        }

        if ( 'last_names' == $output_format ) {
            if ( is_array( $cf_value ) && count( $cf_value ) > 0 ) {
                $last_names = array();
                foreach( $cf_value as $user_id ) {
                    $user_id = (int) $user_id;
                    $user = get_user_by( 'id', $user_id );
                    $last_names[] = $user->user_lastname;
                }
                $last_names = implode(', ', $last_names );
                return $last_names;
            } else {
                return '';
            }
        }
        
        if ( 'display_names' == $output_format ) {
            if ( is_array( $cf_value ) && count( $cf_value ) > 0 ) {
                $display_names = array();
                foreach( $cf_value as $user_id ) {
                    $user_id = (int) $user_id;
                    $user = get_user_by( 'id', $user_id );
                    $display_names[] = $user->display_name;
                }
                $display_names = implode(', ', $display_names );
                return $display_names;
            } else {
                return '';
            }
        }
        
    } else {

    	if ( 'default' == $output_format || 'raw' == $output_format ) {

	        return $cf_value;
    		
    	}

    }

}

function the_cf( $field_name = false, $output_format = 'default', $post_id = false ) {
	
	$cf_value = get_cf( $field_name, $output_format, $post_id );
	
	if ( ! is_array( $cf_value ) ) {
		echo $cf_value;
	} else {
		echo var_dump( $cf_value );		
	}

}

function cf_shortcode_cb( $shortcode_atts ) {
    
    $default_atts = array(
        'name'      => '',
        'output'    => 'default',
        'post_id'   => false,
    );
    
    $atts = shortcode_atts( $default_atts, $shortcode_atts );
    
    return get_cf( $atts['name'], $atts['output'], $atts['post_id'] );
    
}
add_shortcode( 'cf', 'cf_shortcode_cb' );

function get_cf_related_to( $field_name = false, $output_format = 'default', $base_format = 'raw', $post_id = false ) {

    $field_name_slug = str_replace( '_', '-', $field_name );

    if ( in_array( $base_format, array( 'raw', 'api', 'input' ) ) ) {
        $options = array( 'format' => $base_format );
    } else {
        $options = array( 'format' => 'raw' );
    }

    $related_to = CFG()->get( $field_name, $post_id, $options );

    if ( 'default' === $output_format ) {
        return $related_to;        
    }

    if ( false !== strpos( $output_format, 'titles_only_c' ) ) {
    	return cf_titles_only_c( $field_name_slug, $related_to );
    }
    
    if ( false !== strpos( $output_format, 'titles_only_v' ) ) {
    	return cf_titles_only_v( $field_name_slug, $output_format, $related_to );
    }

    if ( false !== strpos( $output_format, 'image_titles_v' ) ) {
    	return cf_image_titles_v( $field_name_slug, $related_to, $output_format );
    }

    if ( false !== strpos( $output_format, 'image_titles_h' ) ) {
    	return cf_image_titles_h( $field_name_slug, $related_to, $output_format );
    }

}

function the_cf_related_to( $field_name = false, $output_format = 'default', $base_format = 'raw', $post_id = false) {
	
	$related_to = get_cf_related_to( $field_name, $output_format, $base_format, $post_id );
	
	if ( ! is_array( $related_to ) ) {
		echo $related_to;
	} else {
		echo var_dump( $related_to );		
	}

}

function cf_related_to_shortcode_cb( $shortcode_atts ) {
    
    $default_atts = array(
        'name'      => '',
        'output'    => 'default',
        'base'      => 'raw',
        'post_id'   => false,
    );
    
    $atts = shortcode_atts( $default_atts, $shortcode_atts );
    
    return get_cf_related_to( $atts['name'], $atts['output'], $atts['base'], $atts['post_id'] );
    
}
add_shortcode( 'cf_related_to', 'cf_related_to_shortcode_cb' );

function get_cf_related_from( $field_name = false, $output_format = 'default', $related_from_post_type = false, $related_from_post_status = 'publish', $field_type = 'relationship', $post_id = false ) {

    $field_name_slug = str_replace( '_', '-', $field_name );

    global $post;
    
    if ( false === $post_id ) {
        $post_id = ( ! empty( $post-> ID ) ) ? $post->ID : get_the_ID();
    }
    
    $options = array( 
        'field_type'    => $field_type,
    );

    if ( false !== $field_name ) {
        $options['field_name'] = $field_name;            
    }

    if ( false !== $related_from_post_type ) {
        $options['post_type'] = $related_from_post_type;            
    }

    if ( false !== $related_from_post_status ) {
        $options['post_status'] = $related_from_post_status;            
    }

    $related_from = CFG()->get_reverse_related( $post_id, $options );
            
    if ( 'default' == $output_format ) {
        return $related_from;
    }
    
    if ( false !== strpos( $output_format, 'titles_only_c' ) ) {
    	return cf_titles_only_c( $field_name_slug, $related_from );
    }

    if ( false !== strpos( $output_format, 'titles_only_v' ) ) {
    	return cf_titles_only_v( $field_name_slug, $output_format, $related_from );
    }

    if ( false !== strpos( $output_format, 'image_titles_v' ) ) {
        return cf_image_titles_v( $field_name_slug, $related_from, $output_format );
    }

    if ( false !== strpos( $output_format, 'image_titles_h' ) ) {
    	return cf_image_titles_h( $field_name_slug, $related_from, $output_format );
    }

}

function the_cf_related_from( $field_name = false, $output_format = 'default', $related_from_post_type = false, $related_from_post_status = 'publish', $field_type = 'relationship', $post_id = false ) {
	
	$related_from = get_cf_related_from( $field_name, $output_format, $related_from_post_type, $related_from_post_status, $field_type, $post_id );
	
	if ( ! is_array( $related_from ) ) {
		echo $related_from;
	} else {
		echo var_dump( $related_from );		
	}

}

function cf_related_from_shortcode_cb( $shortcode_atts ) {
    
    $default_atts = array(
        'name'          => '',
        'output'        => 'default',
        'post_type'     => false,
        'post_status'   => 'publish',
        'field_type'    => 'relationship',
        'post_id'       => false,
    );
    
    $atts = shortcode_atts( $default_atts, $shortcode_atts );
    
    return get_cf_related_from( $atts['name'], $atts['output'], $atts['post_type'], $atts['post_status'], $atts['field_type'], $atts['post_id'] );
    
}
add_shortcode( 'cf_related_from', 'cf_related_from_shortcode_cb' );

/**
 * Output comma separated, linked titles of the related posts/objects
 * @param  string 	$field_name_slug   	slugified $field_name to use for class names
 * @param  array 	$related_ids_array 	array of related post IDs
 */
function cf_titles_only_c( $field_name_slug, $related_ids_array ) {
    $output = '<div class="related related-' . esc_attr( $field_name_slug ) . ' titles-c">';
    if ( is_array( $related_ids_array ) && count( $related_ids_array ) > 0 ) {

        $count = count( $related_ids_array );
        $i = 1;

        foreach ( $related_ids_array as $object_id ) {

            $post = get_post( $object_id );

            if ( is_object( $post ) ) {
                $output .= '<a class="related-item" href="' . get_the_permalink( $object_id ) . '" style="font-size:inherit;font-weight:600;">' . trim( $post->post_title ) . '</a>';

                if ( $i < $count ) { 
                    $output .= ', '; 
                }
            }

            $i++;

        }

    }

    $output .= '</div>';
    
    return $output;
}

/**
 * Output list of linked titles of the related posts/objects
 * @param  string 	$field_name_slug   	slugified $field_name to use for class names
 * @param  array 	$related_ids_array 	array of related post IDs
 */
function cf_titles_only_v( $field_name_slug, $output_format, $related_ids_array ) {
	$output_format = explode( '__', $output_format );
	$list_type = isset( $output_format[1] ) ? $output_format[1] : 'div';
	
	if ( 'div' == $list_type ) {
		$parent_element = 'div';
		$child_element = 'div';
	}
	
	if ( 'ol' == $list_type ) {
		$parent_element = 'ol';
		$child_element = 'li';
	}

	if ( 'ul' == $list_type ) {
		$parent_element = 'ul';
		$child_element = 'li';
	}
	
    $output = '<' . $parent_element . ' class="related related-' . $field_name_slug . ' titles-v">';

    if ( is_array( $related_ids_array ) && count( $related_ids_array ) > 0 ) {

        foreach ( $related_ids_array as $object_id ) {

            $post = get_post( $object_id );

            if ( is_object( $post ) ) {
                $output .= '<' . $child_element . ' class="related-item">
                	<a href="' . get_the_permalink( $object_id ) . '" style="font-size:inherit;font-weight:600;">' . $post->post_title . '</a>
                </' . $child_element . '>';
            }

        }

    }

    $output .= '</' . $parent_element . '>';
    
    return $output;
    
}

/**
 * Output list of linked image-titles of the related posts/objects
 * @param  string 	$field_name_slug   	slugified $field_name to use for class names
 * @param  array 	$related_ids_array 	array of related post IDs
 */
function cf_image_titles_v( $field_name_slug, $related_ids_array, $output_format ) {

    $output = '<div class="related related-' . $field_name_slug . ' image-titles-v" style="display:flex;flex-direction:column;gap:16px;flex-wrap:wrap;">';

    if ( is_array( $related_ids_array ) && count( $related_ids_array ) > 0 ) {

        $output_format_parts = explode( '__', $output_format );
        $image_size = isset( $output_format_parts[1] ) ? $output_format_parts[1] : 'thumbnail';

        foreach ( $related_ids_array as $object_id ) {

            $post = get_post( $object_id );

            if ( is_object( $post ) ) {
                $output .= '<a class="related-item" href="' . get_the_permalink( $post->ID ) . '">
                    <div class="related-item-div" style="display:flex;flex-direction:row;">
                        <img src="' . get_the_post_thumbnail_url( $post->ID, $image_size ) . '" class="custom-field-file-image-as-id" style="width:50px;height:50px;margin-right:8px;">
                        <div style="font-size:inherit;font-weight:600;">' .
                            $post->post_title .
                        '</div>
                </div>
                </a>';
            }

        }

    }

    $output .= '</div>';

    return $output;
}

/**
 * Output horizontal grid of linked image-titles of the related posts/objects
 * @param  string 	$field_name_slug   	slugified $field_name to use for class names
 * @param  array 	$related_ids_array 	array of related post IDs
 */
function cf_image_titles_h( $field_name_slug, $related_ids_array, $output_format ) {

    $output = '<div class="related related-' . $field_name_slug . ' image-titles-h" style="display:flex;gap:16px;flex-wrap:wrap;">';

    if ( is_array( $related_ids_array ) && count( $related_ids_array ) > 0 ) {

        $output_format_parts = explode( '__', $output_format );
        $image_size = isset( $output_format_parts[1] ) ? $output_format_parts[1] : 'thumbnail';

        foreach ( $related_ids_array as $object_id ) {

            $post = get_post( $object_id );
            $featured_image_id = get_post_thumbnail_id( $object_id );
            $image_info = wp_get_attachment_image_src( $featured_image_id, $image_size );

            if ( $image_info ) {
            	$image_width = $image_info[1];
            } else {
            	$image_width = get_option( $image_size . '_size_w', '150' );
            }

            if ( is_object( $post ) ) {

                $output .= '<a class="related-item" href="' . get_the_permalink( $post->ID ) . '">
                    <div class="related-item-div" style="max-width:' . $image_width . 'px">
                        ' . get_the_post_thumbnail( $post->ID, $image_size ) . '
                        <div style="font-size:inherit;font-weight:600;text-align:center;">
                            ' . $post->post_title . '
                        </div>
                </div>
                </a>';

            }

        }

    }

    $output .= '</div>';
    
    return $output;

}