<?php
/**
 * Blank comment template which replaces theme's comment template
 * when comment is disabled for the post type
 * 
 * @since 4.9.2
 */