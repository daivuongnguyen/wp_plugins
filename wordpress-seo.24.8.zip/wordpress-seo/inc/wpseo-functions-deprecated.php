<?php
/**
 * WPSEO plugin file.
 *
 * @package WPSEO\Deprecated
 */
