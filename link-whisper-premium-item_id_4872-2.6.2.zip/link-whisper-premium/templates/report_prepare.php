<div class="wrap">
    <h1 class="wp-heading-inline"><?php esc_html_e("Internal Links Report","wpil"); ?></h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">
                <p><?php esc_html_e("Prepare data, completed","wpil"); ?>: <span class=wpil-loading-status><?=esc_html($st['status'])?></span></p>
                <div class="syns_div wpil_report_need_prepare">
                    <h4 class="progress_panel_msg hide"><?php esc_html_e('Synchronizing your data..','wpil'); ?></h4>
                    <div class="progress_panel" data-total="<?php echo esc_attr($st['remained'])?>">
                        <div class="progress_count" style='width: <?=$st['w']?>%'><span class=wpil-loading-status><?=esc_html($st['status'])?></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>